//
//  ViewController.swift
//  UNTZ
//
//  Created by Mahesh Sonaiya on 13/04/17.
//  Copyright © 2017 Mahesh Sonaiya. All rights reserved.
//

import UIKit
import SDWebImage
import MBProgressHUD
import CoreLocation

class ViewController: UIViewController ,CLLocationManagerDelegate {
    
    var locationManager :CLLocationManager = CLLocationManager()

    @IBOutlet var localityTxtField: UNLabel!
    @IBOutlet var postalCodeTxtField: UNLabel!
    @IBOutlet var aAreaTxtField: UNLabel!
    @IBOutlet var countryTxtField: UNLabel!
    
    @IBOutlet var ImgGifV: UIImageView!
  var HUD: MBProgressHUD = MBProgressHUD()
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        self.navigationItem.title = "Home"
        //navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Left", style: .plain, target: self, action: #selector(showLeftView(sender:)))
       
        // Do any additional setup after loading the view.
        
        let imageData = NSData(contentsOf: Bundle.main.url(forResource: "animationImg",withExtension: "gif")!)
        ImgGifV.image = UIImage.sd_animatedGIF(with: imageData as Data!)
        startLocation(self)
        
    }
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        self.view.frame = CGRect(x: 0.0, y: 0.0, width: view.frame.size.width, height: view.frame.size.height)
        //self.view.backgroundColor = UIColor.yellow
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

   
    
     func startLocation(_ sender: Any) {
        // Ask for Authorisation from the User.
        //self.locationManager.requestAlwaysAuthorization()
        
        // For use in foreground
        self.locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.startUpdatingLocation()
        //GLOBAL.sharedInstance.showLoadingIndicatorWithMessage("")
      }
        
    }
    // MARK: -
    
    func showLeftView(sender: AnyObject?) {
        sideMenuController?.showLeftView(animated: true, completionHandler: nil)
    }
    
    func showRightView(sender: AnyObject?) {
        sideMenuController?.showRightView(animated: true, completionHandler: nil)
    }
    
    //CLLocationManagerDelegate
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        CLGeocoder().reverseGeocodeLocation(manager.location!, completionHandler: {(placemarks, error)->Void in
            
            if (error != nil) {
                print("Reverse geocoder failed with error" + (error?.localizedDescription)!)
                return
            }
            

            
            if (placemarks?.count)! > 0 {
                var placemark : CLPlacemark!
                placemark = placemarks?[0]
                self.displayLocationInfo(placemark: placemark)
            } else {
                print("Problem with the data received from geocoder")
            }
        })
        GLOBAL.sharedInstance.hideLoadingIndicator()
    }
    func displayLocationInfo(placemark: CLPlacemark?) {
        if let containsPlacemark = placemark {
            //stop updating location to save battery life
            locationManager.stopUpdatingLocation()
            let locality = (containsPlacemark.locality != nil) ? containsPlacemark.locality : ""
            let postalCode = (containsPlacemark.postalCode != nil) ? containsPlacemark.postalCode : ""
            let administrativeArea = (containsPlacemark.administrativeArea != nil) ? containsPlacemark.administrativeArea : ""
            
            
            localityTxtField.text = String.init(format: "%@ %@", locality!,administrativeArea!)
            postalCodeTxtField.text = postalCode
            
            let latitude : String = "Latitude : " + "\(placemark?.location?.coordinate.latitude as Any)"
            aAreaTxtField.text = latitude
            
            let longitude : String = "Longitude : " + "\(placemark?.location?.coordinate.longitude as Any)"
            countryTxtField.text = longitude


            print(placemark?.location?.coordinate.latitude as Any)
            print(placemark?.location?.coordinate.longitude as Any)

        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
        GLOBAL.sharedInstance.hideLoadingIndicator()
        //txtLatitude.text = "Can't get your location!"
        let status = CLLocationManager.authorizationStatus()
        if(status == CLAuthorizationStatus.denied) {
        let alert=UIAlertController(title: "App Permission Denied", message: "To re-enable, please go to Settings and turn on Location Service for this app.", preferredStyle: UIAlertControllerStyle.alert);
        //show it
        show(alert, sender: self);
        }
    }

    func locationManager(_ manager: CLLocationManager,
                         didChangeAuthorization status: CLAuthorizationStatus) {
        var shouldIAllow = false
        var locationStatus = ""
        switch status {
        case CLAuthorizationStatus.restricted:
            locationStatus = "Restricted Access to location"
        case CLAuthorizationStatus.denied:
            locationStatus = "User denied access to location"
        case CLAuthorizationStatus.notDetermined:
            locationStatus = "Status not determined"
        default:
            locationStatus = "Allowed to location Access"
            shouldIAllow = true
        }
        if (shouldIAllow == true) {
            NSLog("Location to Allowed")
            // Start location services
            locationManager.startUpdatingLocation()
        } else {
            NSLog("Denied access: \(locationStatus)")
        }
    }
}

