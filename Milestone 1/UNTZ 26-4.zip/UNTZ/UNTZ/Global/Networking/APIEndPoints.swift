//
//  APIEndPoints.swift
//  Enmoji
//
//  Created by Mahesh on 16/12/16.
//  Copyright © 2016 brainvire. All rights reserved.
//

import Foundation

class APIEndPoints {
    static func getBaseURL() -> String {
        return "http://enmoji.demo.brainvire.com/api/"
    }

    static func getVersion1APIURL() -> String {
        return getBaseURL() + "v1/"
    }

    static func getLoginURL() -> String {
        return getVersion1APIURL() + "login"
    }
    
    static func getRegisterURL() -> String {
        return getVersion1APIURL() + "register"
    }
    
    static func getForgotPasswordURL() -> String {
        return getVersion1APIURL() + "forgotpassword"
    }
    
    static func getEmojiOrStickersURL() -> String {
        return getVersion1APIURL() + "GetEmojiOrSticker"
    }
    
    static func setMostViewedURL() -> String {
        return getVersion1APIURL() + "setMostViewed"
    }
    
    static func getMostRecommendedURL() -> String {
        return getVersion1APIURL() + ""
    }
    
    static func registerDeviceToken() -> String {
        return getVersion1APIURL() + "registerForPush"
    }
    
    static func enableOrDisablePushNotificaionURL() -> String {
        return getVersion1APIURL() + "pushNotificationSetting"
    }
    
    static func getItemListURL() -> String {
        return getVersion1APIURL() + "getItemList"
    }
    
    static func partnerWithUsURL() -> String {
        return getVersion1APIURL() + "partnerWithUs"
    }
    
    static func contactUsURL() -> String {
        return getVersion1APIURL() + "contactUs"
    }
    
    static func aboutUsURL() -> String {
        return getVersion1APIURL() + "getInfoPage"
    }

    static func getMyDownloadsURL() -> String {
        return getVersion1APIURL() + "getMyDownloads"
    }
    
    static func saveProfileURL() -> String {
        return getVersion1APIURL() + "saveProfile"
    }
    
    static func getProfileURL() -> String {
        return getVersion1APIURL() + "getProfile"
    }
    
}
