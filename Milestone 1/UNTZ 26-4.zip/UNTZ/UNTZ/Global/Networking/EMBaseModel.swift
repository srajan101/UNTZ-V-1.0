//
//  EMBaseModel.swift
//  Enmoji
//
//  Created by Mahesh on 15/12/16.
//  Copyright © 2016 brainvire. All rights reserved.
//

import Foundation

class EMBaseModel {
    

    var status: String?
    var success: String?
    var message : String?
    
    init(jsonDict: Dictionary<String, AnyObject>) {
        
        self.status = jsonDict[EMAPIResponseStatusKeys.status] as? String
        self.message = jsonDict[EMAPIResponseStatusKeys.message] as? String
    }
}

class EMResponseModel {
    
    var status: String?
    var success: String?
    var message : String?
    var data : Dictionary<String,AnyObject>?
    var tokenData : Dictionary<String,AnyObject>?
    
    init(jsonDict: Dictionary<String, AnyObject>) {
        
        self.status = jsonDict[EMAPIResponseStatusKeys.status] as? String
        self.message = jsonDict[EMAPIResponseStatusKeys.message] as? String
        
        if(self.status == EMAPIResponseStatusKeys.success){
            data = jsonDict[EMAPIResponseStatusKeys.data] as? Dictionary<String,AnyObject>
        }
        
        if jsonDict[EMAPIResponseStatusKeys.tokenData] != nil {
            tokenData = jsonDict[EMAPIResponseStatusKeys.tokenData] as? Dictionary<String,AnyObject>
        }
        
    }
}


