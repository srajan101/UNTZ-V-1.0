//
//  UserInfo.swift
//  Enmoji
//
//  Created by Mahesh on 22/12/16.
//  Copyright © 2016 brainvire. All rights reserved.
//

import Foundation
import FacebookCore
import FacebookLogin

class UserInfo : NSObject {
    
    static let sharedInstance = UserInfo()

    fileprivate override init() {
        super.init()
    }
    
    // MARK: - Get-Set NSUserDefaults Global Value
    func setUserInfoInCache(value : AnyObject?  , key : String)
    {
        let defaults = UserDefaults.standard
        
        if (value != nil){
            defaults.set(value, forKey: key)
        }
        defaults.synchronize()
    }
    
    func getUserDefault(key : String) -> AnyObject?
    {
        let defaults = UserDefaults.standard
        
        if let name = defaults.value(forKey: key){
            return name as AnyObject?
        }
        return nil
    }
    
    func removeCacheValue(key : String)
    {
        let defaults = UserDefaults.standard
        
        if defaults.value(forKey: key) != nil{
            defaults.removeObject(forKey: key)
        }
    }
    
    func clearUserInfoWhenUserLoggedOut() {
        let socialUserType = UserInfo.sharedInstance.getUserDefault(key: EMUserInfoKeys.userType)
        
        if let socialUserType = socialUserType {
            let socialUserTypeValue = socialUserType as! Int
            if (socialUserTypeValue == EMUserTypes.socialTypeFacebook) {
                LoginManager().logOut()
            }
            
        }

        
        UserInfo.sharedInstance.removeCacheValue(key: EMUserInfoKeys.userID)
        UserInfo.sharedInstance.removeCacheValue(key: EMUserInfoKeys.userName)
        UserInfo.sharedInstance.removeCacheValue(key: EMUserInfoKeys.profilePic)
        UserInfo.sharedInstance.removeCacheValue(key: EMUserInfoKeys.emailID)
        UserInfo.sharedInstance.removeCacheValue(key: EMUserInfoKeys.isSocialUser)
        UserInfo.sharedInstance.removeCacheValue(key: EMUserInfoKeys.socialId)
        UserInfo.sharedInstance.removeCacheValue(key: EMUserInfoKeys.userType)
        UserInfo.sharedInstance.removeCacheValue(key: EMUserInfoKeys.userID)
        
        UserInfo.sharedInstance.removeCacheValue(key: EMUserInfoKeys.accessToken)
        UserInfo.sharedInstance.removeCacheValue(key: EMUserInfoKeys.refreshToken)
        UserInfo.sharedInstance.removeCacheValue(key: EMUserInfoKeys.tokenExpiresIn)
        UserInfo.sharedInstance.removeCacheValue(key: EMUserInfoKeys.tokenType)
        
        UserInfo.sharedInstance.setUserInfoInCache(value: false as AnyObject?, key: EMUserInfoKeys.isUserLoggedIn)
        
        NotificationCenter.default.post(name: Notification.Name(LocalNotification.logoutNotification), object: nil)
    }
}
