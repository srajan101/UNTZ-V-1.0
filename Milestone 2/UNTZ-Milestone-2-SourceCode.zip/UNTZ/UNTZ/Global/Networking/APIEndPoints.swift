//
//  APIEndPoints.swift
//  Enmoji
//
//  Created by Mahesh on 16/12/16.
//  Copyright © 2016 Mahesh Sonaiya. All rights reserved.
//

import Foundation

class APIEndPoints {
    static func getBaseURL() -> String {
        return "https://untz.azurewebsites.net/api/"
    }

    static func getEventCategoryURL() -> String {
        return getBaseURL() + "Event/"
    }

    static func getLoginURL() -> String {
        return getEventCategoryURL() + "login"
    }
    
    static func getListOfEventCategories() -> String {
        return getEventCategoryURL() + "Category"
    }
    
    static func getSuggestedEventsList() -> String {
        return getEventCategoryURL() + "SuggestedEvents"
    }
    
}
