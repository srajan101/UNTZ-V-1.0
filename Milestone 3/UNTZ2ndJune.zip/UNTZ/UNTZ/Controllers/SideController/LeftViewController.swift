//
//  LeftViewController.swift
//  LGSideMenuControllerDemo
//
import FBSDKLoginKit


class LeftViewController: UITableViewController {
    
    private let titlesArray = ["Home","Create Event","My Upcoming Events","Profile","About Us","Contact Us","Logout"]
    var dict : [String : AnyObject]!
    
    init() {
        super.init(style: .plain)
        
        view.backgroundColor = .clear
        
        tableView.register(LeftViewCell.self, forCellReuseIdentifier: "cell")
        tableView.separatorStyle = .none
        tableView.contentInset = UIEdgeInsets(top: 44.0, left: 0.0, bottom: 44.0, right: 0.0)
        tableView.showsVerticalScrollIndicator = false
        tableView.backgroundColor = .clear
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .default
    }
    
    override var preferredStatusBarUpdateAnimation: UIStatusBarAnimation {
        return .fade
    }
    
    // MARK: - UITableViewDataSource
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if FBSDKAccessToken.current() != nil {
            return titlesArray.count
        }
        return titlesArray.count-1
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! LeftViewCell
        if FBSDKAccessToken.current() == nil && indexPath.row == 3 {
            cell.textLabel!.text = "LogIn"
        }else{
            cell.textLabel!.text = titlesArray[indexPath.row]
        }
        
        return cell
    }
    
    // MARK: - UITableViewDelegate
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50;
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let mainViewController = sideMenuController!
        if indexPath.row == 3 {
            if FBSDKAccessToken.current() != nil {
                //profile
             mainViewController.hideLeftView(animated: true, delay: 0.0, completionHandler: nil)
            }
            else{
               mainViewController.hideLeftView(animated: true, delay: 0.0, completionHandler: nil)
                let fbLoginManager : FBSDKLoginManager = FBSDKLoginManager()
                fbLoginManager.logIn(withReadPermissions: ["email"], from: self) { (result, error) in
                    if(error != nil){
                        FBSDKLoginManager().logOut()
                    }else if(result?.isCancelled)!{
                        FBSDKLoginManager().logOut()
                    }else{
                                print("Getting profile")
                                print("FB version: \(FBSDKSettings.sdkVersion())")
                                print("Tokensssss:  \(String(describing: FBSDKAccessToken.current()?.tokenString))")
                                //self.getFBUserData()
                        UNTZReqeustManager.sharedInstance.apiFacebookLogin((FBSDKAccessToken.current()?.tokenString)!, provider: "Facebook", completionHandler:{ (feedResponse) -> Void in
                            if let downloadError = feedResponse.error{
                                print(downloadError)
                                GLOBAL().showAlert(APPLICATION.applicationName, message: downloadError.localizedDescription, actions: nil)
                            } else {
                                print("\(feedResponse)")
                                mainViewController.hideLeftView(animated: true, delay: 0.0, completionHandler: nil)
                                tableView.reloadData()
                            }
                        })
                    }
                  }
            }
        
        }
        else if indexPath.row == 6 {
            //logout
            FBSDKLoginManager().logOut()
            mainViewController.hideLeftView(animated: true, delay: 0.0, completionHandler: nil)
            tableView.reloadData()
        }
        else{
           mainViewController.hideLeftView(animated: true, delay: 0.0, completionHandler: nil)
        }
        
       /* else if indexPath.row == 2 {
            let navigationController = mainViewController.rootViewController as! NavigationController
            let viewController: UIViewController!
            viewController = HomeViewController()
            navigationController.setViewControllers([viewController], animated: false)
            // Rarely you can get some visual bugs when you change view hierarchy and toggle side views in the same iteration
            // You can use delay to avoid this and probably other unexpected visual bugs
            mainViewController.hideLeftView(animated: true, delay: 0.0, completionHandler: nil)
        }
        else {
            let viewController = UIViewController()
            viewController.view.backgroundColor = .white
            viewController.title = "Test \(titlesArray[indexPath.row])"
            
            let navigationController = mainViewController.rootViewController as! NavigationController
            navigationController.pushViewController(viewController, animated: true)
            
            mainViewController.hideLeftView(animated: true, completionHandler: nil)
        }
        */
    }
    func getFBUserData(){
        if((FBSDKAccessToken.current()) != nil){
            FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name, last_name, picture.type(large), email"]).start(completionHandler: { (connection, result, error) -> Void in
                if (error == nil){
                    self.dict = result as! [String : AnyObject]
                    print(result!)
                    print(self.dict)
                }
            })
        }
    }
}
