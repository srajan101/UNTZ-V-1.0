//
//  NotificationsViewController.swift
//  UNTZ
//
//  Created by Mahesh Sonaiya on 14/04/18.
//  Copyright © 2018 Mahesh Sonaiya. All rights reserved.
//

import UIKit

class NotificationsViewController: UIViewController , UITableViewDelegate, UITableViewDataSource{
    
    @IBOutlet weak var notificationTableView: UITableView!
    @IBOutlet weak var noresultLabel: UNLabel!
    
    var notificationRespone : [NotificationRespone]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        notificationTableView.register(UINib(nibName: "FansListCell", bundle: nil), forCellReuseIdentifier: "fanCell")
        notificationTableView.estimatedRowHeight = notificationTableView.rowHeight
        notificationTableView.rowHeight = UITableViewAutomaticDimension
        
        //self.getListOfFans(self.userId!)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //self.navigationController?.navigationBar.isHidden = true
        
        addCustomNavBar(self, isMenuRequired: false, title: "Notifications", backhandler: {
            self.navigationController?.popViewController(animated: true)
        })
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        self.notificationTableView.reloadData()
    }
    
    @IBAction func backClicked(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK :- Get List Of Notifications
    
    func getListOfNotifications() {
        GLOBAL().showLoadingIndicatorWithMessage("")
        UNTZReqeustManager.sharedInstance.apiGetNotificationList() {
        (feedResponse) -> Void in
            GLOBAL().hideLoadingIndicator()
            
            if let downloadError = feedResponse.error{
                print(downloadError)
                GLOBAL().showAlert(APPLICATION.applicationName, message: downloadError.localizedDescription, actions: nil)
            } else {
                GLOBAL().hideLoadingIndicator()
                
                if let dictionary = feedResponse.responseDict as? Dictionary<String, AnyObject>{
                    if let notificationArray = dictionary["data"] as? Array<Dictionary<String, AnyObject>> {
                        for notification in notificationArray{
                            let notificationObj = NotificationRespone.init(jsonDict: notification)
                            self.notificationRespone?.append(notificationObj)
                        }
                    }
                    
                    if self.notificationRespone?.count==0{
                        self.noresultLabel.isHidden = false
                    }else{
                        self.noresultLabel.isHidden = true
                    }
                    
                    self.notificationTableView.reloadData()
                }
            }
        }
    }
    // number of rows in table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.notificationRespone == nil {
            return 0
        } else
        {
            return (self.notificationRespone?.count)!;
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 85;//Choose your custom row height
    }
    
    // create a cell for each table view row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        /*
        let cell:FansListCell = tableView.dequeueReusableCell(withIdentifier: "fanCell") as! FansListCell
        //cell.selectionStyle = UITableViewCellSelectionStyle.none
        let objfansDetails = self.fansResponse?.fansList[indexPath.row]
        let fansaccobj  = objfansDetails?.fanAccount
        cell.NameLabel.text = fansaccobj?.fullName
        if fansaccobj?.pictureUrl != nil{
            cell.profileImageView.sd_setImage(with: URL.init(string: (fansaccobj?.pictureUrl)!), completed: { (image, error, cacheType, imageURL) in
                //cell.linkImageview.stopAnimationOfImage()
            })
        }else{
            let Image: UIImage = UIImage(named: "profile_default")!
            cell.profileImageView.image = Image
        }
        return cell
    */
        return UITableViewCell()
    }
 
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        /*let objfansDetails = self.fansResponse?.fansList[indexPath.row]
        let fansaccobj  = objfansDetails?.fanAccount
        let detailObj = makeStoryObj(storyboard: storyboard_R1, Identifier: "IDProfileVC") as! ProfileViewController
        detailObj.isFanProfile = true
        detailObj.userID = String.init(format: "%ld", (fansaccobj?.id)!)
        pushStoryObj(obj: detailObj, on: self)
         */
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
