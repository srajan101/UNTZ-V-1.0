//
//  AppDelegate.swift
//  UNTZ
//
//  Created by Mahesh Sonaiya on 13/04/17.
//  Copyright © 2017 Mahesh Sonaiya. All rights reserved.
//

import UIKit
import FBSDKLoginKit
import UserNotifications
import BRYXBanner
import Fabric
import Crashlytics
import SDWebImage

struct NotificationState {
    static var initialLoadFlag = false
}

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate , UNUserNotificationCenterDelegate {
    
    var window: UIWindow?
    
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        Fabric.with([Crashlytics.self])

        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "IDViewController")
        
        
        //let viewController: UIViewController = ViewController()
        
        let navigationController = NavigationController(rootViewController: viewController)
        let mainViewController = MainViewController()
        mainViewController.isRightViewStatusBarHidden = true
        mainViewController.rootViewController = navigationController
        mainViewController.setup(type: UInt(0))
        
        window = UIWindow(frame: UIScreen.main.bounds)
        window!.backgroundColor = .white
        window!.rootViewController = mainViewController
        window!.makeKeyAndVisible()
        
        //Internet reachability
        GLOBAL().startNotifier()
        
        UINavigationBar.appearance().barTintColor = UIColor(red: 190/255, green: 20/255, blue: 17/255, alpha: 1)
        UINavigationBar.appearance().tintColor = UIColor.white
        UINavigationBar.appearance().titleTextAttributes = [NSForegroundColorAttributeName:UIColor.white]
        UIApplication.shared.statusBarStyle = .lightContent
        
        UIApplication.shared.applicationIconBadgeNumber = 0


        initializeCloudContainer()
        
        // iOS 10 support
        if #available(iOS 10, *) {
            let center = UNUserNotificationCenter.current()
            center.delegate = self
            center.requestAuthorization(options:[.badge, .alert, .sound]) { (granted, error) in
                // Enable or disable features based on authorization.
            }
            application.registerForRemoteNotifications()
        }
            // iOS 9 support
        else if #available(iOS 9, *) {
            UIApplication.shared.registerUserNotificationSettings(UIUserNotificationSettings(types: [.badge, .sound, .alert], categories: nil))
            UIApplication.shared.registerForRemoteNotifications()
        }

        SDImageCache.shared().config.shouldDecompressImages = false
        SDWebImageDownloader.shared().shouldDecompressImages = false
        SDImageCache.shared().config.maxCacheSize = (100 * 1024 * 1024) // 100 MB
        SDImageCache.shared().config.maxCacheAge = (60 * 60 * 24 * 3)
        
        
        return FBSDKApplicationDelegate.sharedInstance().application(application, didFinishLaunchingWithOptions: launchOptions)
    }
    // Called when APNs has assigned the device a unique token
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        
        let deviceTokenString = deviceToken.reduce("", {$0 + String(format: "%02X", $1)})
        print("APNs registration Token \(deviceTokenString)")
        let defaults = UserDefaults.standard
        defaults.set(deviceTokenString, forKey: CacheConstants.deviceToken)
        
    }
    
    // Called when APNs failed to register the device for push notifications
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        // Print the error to console (you should alert the user that registration failed)
        print("APNs registration failed: \(error)")
    }
    // Push notification received
    func application(_ application: UIApplication, didReceiveRemoteNotification data: [AnyHashable : Any]) {
        // Print notification payload data
        print("Push notification received: \(data)")
        NotificationState.initialLoadFlag = true
    }
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
         let userInfo = notification.request.content.userInfo
        //Handle notification
        print("Data1 received: \(userInfo)")
        
        NotificationState.initialLoadFlag = true
        
        let alert = userInfo["aps"]! as! NSDictionary
        let body = alert["alert"] as! String
        let banner2 = Banner(title: "UNTZ", subtitle: body, image:UIImage(named:"logoImg") , backgroundColor: UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1.0)) {
            self.movetoNotificationController()
        }
        banner2.textColor  =  UIColor(red: 190/255, green: 20/255, blue: 17/255, alpha: 1.0)
        banner2.dismissesOnTap = true
        banner2.show(duration: 10.0)
        
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ReloadBellIcon"), object: self)
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ReloadMenu"), object: self)
    }
    
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        // pull out the buried userInfo dictionary
        let userInfo = response.notification.request.content.userInfo
        print("Data2 received: \(userInfo)")
        
        NotificationState.initialLoadFlag = true
        
        self.movetoNotificationController()
        
//        if let customData = userInfo["customData"] as? String {
//            print("Custom data received: \(customData)")
//
//            switch response.actionIdentifier {
//            case UNNotificationDefaultActionIdentifier:
//                // the user swiped to unlock
//                print("Default identifier")
//
//            case "show":
//                // the user tapped our "show more info…" button
//                print("Show more information…")
//                break
//
//            default:
//                break
//            }
//        }
        
        // you must call the completion handler when you're done
        completionHandler()
    }
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
        FBSDKAppEvents.activateApp()
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        if UIApplication.shared.applicationIconBadgeNumber > 0 {
            NotificationState.initialLoadFlag = true
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ReloadBellIcon"), object: self)
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ReloadMenu"), object: self)
            UIApplication.shared.applicationIconBadgeNumber = 0
        }
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    /*func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool {
        
        return FBSDKApplicationDelegate.sharedInstance().application(application, open: url, sourceApplication: sourceApplication, annotation: annotation)
    }
    */
    // MARK: Universal Links
    func application(_ application: UIApplication, continue userActivity: NSUserActivity, restorationHandler: @escaping ([Any]?) -> Void) -> Bool {
        if userActivity.activityType == NSUserActivityTypeBrowsingWeb {
            if let url = userActivity.webpageURL {
                print("URL : \(url)")
            }
        }
        return false
    }
    func application(_ app: UIApplication, open url: URL, options: [UIApplicationOpenURLOptionsKey : Any] = [:]) -> Bool {
        
        print("URL : \(url)")
        if(url.scheme!.isEqual("fb1831890057054527")) {
            print("Facebook url scheme")
            
            return FBSDKApplicationDelegate.sharedInstance().application(app, open: url, sourceApplication: options[UIApplicationOpenURLOptionsKey.sourceApplication] as? String, annotation: options[UIApplicationOpenURLOptionsKey.annotation])
            
        } else {
            if let sourceApplication = options[.sourceApplication] {
                if (String(describing: sourceApplication) == "com.apple.SafariViewService") {
                    return SpotifyLoginManager.shared.handled(url: url)
                }
            }
        }
    
        /*
        else if(url.scheme!.isEqual("fb1831890057054527")) {
            return FBSDKApplicationDelegate.sharedInstance().application(app, open: url, sourceApplication: options[UIApplicationOpenURLOptionsKey.sourceApplication] as? String, annotation: options[UIApplicationOpenURLOptionsKey.annotation])
            
        }
 */
        return false
    }
    
    func movetoNotificationController() {
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            // your code here
                if let topController = UIApplication.shared.keyWindow?.rootViewController {
                    let mainViewController = topController.sideMenuController!
                    let navigationController = mainViewController.rootViewController as! NavigationController
                        let viewController = storyboard_R1.instantiateViewController(withIdentifier: "IDNotificationVC") as! NotificationsViewController
                            let defaults = UserDefaults.standard
                            let accountId = defaults.integer(forKey: UNUserInfoKeys.accountID)
                            let accountIdValue = String.init(format: "%@", NSNumber.init(value: accountId))
                            viewController.accountId = accountIdValue
                            viewController.isPushVC = false
                            navigationController.setViewControllers([viewController], animated: false)
                            mainViewController.hideLeftView(animated: true, delay: 0.0, completionHandler: nil)
                }
        }
       
    }
    
    func initializeCloudContainer() {
        AzureCloudStorageManager.sharedInstance.initAzureCloudStorageManager()
    }
}

