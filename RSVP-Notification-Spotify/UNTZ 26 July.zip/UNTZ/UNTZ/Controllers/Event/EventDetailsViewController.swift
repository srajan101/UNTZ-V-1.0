//
//  EventDetailsViewController.swift
//  UNTZ
//
//  Created by Mahesh on 14/06/17.
//  Copyright © 2017 Mahesh Sonaiya. All rights reserved.
//

import UIKit
import TTTAttributedLabel

enum EventStates: Int {
    case MarkAsInterested = 1,
    DeleteEvent,
    JoinEvent,
    LeaveEvent,
    MakeItLive,
    CancelEvent,
    UndoCancelEvent,
    AttendingEvent
}

class EventDetailsViewController: UIViewController, UIGestureRecognizerDelegate,TTTAttributedLabelDelegate {

    var eventDetailsResponse : EventDetailsResponse?
    open var eventId : Int?
    open var eventImageURL : String?
    //var contentSize : CGFloat?
    
    @IBOutlet weak var eventImageView: UIImageView!
    @IBOutlet weak var hostedByLabel: TTTAttributedLabel!
    @IBOutlet weak var placeLable: UNLabel!
    @IBOutlet weak var peopleCountLabel: UNLabel!
    @IBOutlet weak var timeLabel: UNLabel!
    @IBOutlet weak var dateDayLabel: UNLabel!
    @IBOutlet weak var eventNameLabel: UNLabel!
    
    @IBOutlet weak var dateMonthLabel: UNLabel!
    
    @IBOutlet weak var performingLbl: UILabel!
    @IBOutlet weak var performTimeLbl: UILabel!
    @IBOutlet weak var eventTypeLabel: UNLabel!
    @IBOutlet weak var eventTextLabel: UNLabel!
    
    @IBOutlet weak var profileImageview: UIImageView!
    @IBOutlet weak var scrollview: UIScrollView!
    
    @IBOutlet weak var detailview: UIView!
    @IBOutlet weak var shadowview: UIView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var interestedButton: UNButton!
    @IBOutlet weak var artistsButton : UNButton!
    @IBOutlet weak var aboutUsButton: UNButton!
    @IBOutlet weak var secondActionButton: UNButton!
    @IBOutlet weak var artistView: UIView!
    @IBOutlet weak var aboutUsView: UIView!
    @IBOutlet weak var firstActionView: UIView!
    @IBOutlet weak var secondActionView: UIView!
    @IBOutlet weak var firstActionImageView: UIImageView!
    @IBOutlet weak var secondActionImageView: UIImageView!
    @IBOutlet weak var happeningTextButton: UNButton!
    @IBOutlet weak var requestTextButton: UNButton!
    @IBOutlet weak var playlistTextButton: UNButton!
    @IBOutlet weak var userdisplayView: UIView!
    @IBOutlet weak var DisplayTypeView: UIView!
    @IBOutlet weak var belowButtonView: UIView!
    
    @IBOutlet weak var contentViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var songImageView : UIImageView!
    @IBOutlet weak var songTitle : UNLabel!
    @IBOutlet weak var artistName : UNLabel!
    
    @IBOutlet weak var buttonViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var adminNamesHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var mainViewHeightConstraint : NSLayoutConstraint!
    @IBOutlet weak var shadowViewHeightConstraint : NSLayoutConstraint!
    @IBOutlet weak var displayTypeHeightConstraint : NSLayoutConstraint!
    @IBOutlet weak var currentSongPlayingHeightConstraint : NSLayoutConstraint!
    @IBOutlet weak var currentSongPlayingTopSpaceConstraint : NSLayoutConstraint!
    @IBOutlet weak var buttonWidthConstraint : NSLayoutConstraint!
    @IBOutlet weak var buttonHeightConstraint : NSLayoutConstraint!
    
    fileprivate let imageHeight : CGFloat = 250.0
    fileprivate let mainViewHeight : CGFloat = 250.0
    fileprivate let shadowViewHeight : CGFloat = 260.0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        initSetUp()
        
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(self.reloadnotificationbar),
            name: NSNotification.Name(rawValue: "ReloadBellIcon"),
            object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(HomeViewController.imageDidLoadNotification(withNotification:)), name: NSNotification.Name(rawValue: "ReloadEventDetails"), object: nil)
        
        self.reloadImage()
        
        self.getEventDetails()
        
        let tapGestureImg = UITapGestureRecognizer(target: self, action: #selector(handleImageTap(sender:)))
        self.eventImageView.isUserInteractionEnabled = true
        self.eventImageView.addGestureRecognizer(tapGestureImg)
        
        shadowview.setViewShadow()
        
        profileImageview.layer.cornerRadius = profileImageview.frame.size.height/2
        profileImageview.clipsToBounds = true

        if (UserInfo.sharedInstance.getUserDefault(key: UNUserInfoKeys.Imageurl) != nil) {
            profileImageview.sd_setImage(with: URL(string: UserInfo.sharedInstance.getUserDefault(key: UNUserInfoKeys.Imageurl) as! String), placeholderImage: UIImage.init(named: "default_user_pict"))
        }

        setClickEvents()
    }
    
    func setClickEvents() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(sender:)))
        profileImageview.isUserInteractionEnabled = true
        profileImageview.addGestureRecognizer(tapGesture)

        let artistTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleArtistClickEvent(sender:)))
        artistView.isUserInteractionEnabled = true
        artistView.addGestureRecognizer(artistTapGesture)

        let aboutTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleAboutClickEvent(sender:)))
        aboutUsView.isUserInteractionEnabled = true
        aboutUsView.addGestureRecognizer(aboutTapGesture)
    }
    
    func reloadImage() {
        if let eventImageURL = eventImageURL {
            self.eventImageView.sd_setImage(with: URL.init(string: eventImageURL))      { (image, error, imageCacheType, imageUrl) in
                
                DispatchQueue.main.async {
                    if image != nil {
                        let height = self.imageHeight
                        
                        self.mainViewHeightConstraint = self.mainView.heightAnchor.constraint(greaterThanOrEqualToConstant: CGFloat(self.mainViewHeight + height))
                        
                        self.shadowViewHeightConstraint = self.shadowview.heightAnchor.constraint(greaterThanOrEqualToConstant: CGFloat(self.shadowViewHeight + height))
                        //self.contentSize = self.shadowViewHeightConstraint.constant
                        self.contentViewHeightConstraint.constant = self.shadowViewHeightConstraint.constant
                    } else {
                        
                        self.eventImageView.image = UIImage.init(named: "default_image")
                        let height = self.imageHeight
                        
                        self.mainViewHeightConstraint.constant = CGFloat(self.mainViewHeight + height)
                        self.shadowViewHeightConstraint.constant = CGFloat(self.shadowViewHeight + height)
                        
                        //self.contentSize = self.shadowViewHeightConstraint.constant
                        self.contentViewHeightConstraint.constant = self.shadowViewHeightConstraint.constant
                    }
                }
                
                
            }
        }
    }
    
    
    func reloadImageRefresh() {
        if let eventImageURL = eventImageURL {
            self.eventImageView.sd_setImage(with: URL.init(string: eventImageURL))      { (image, error, imageCacheType, imageUrl) in
                
                DispatchQueue.main.async {
                    if image != nil {
                        let height = self.imageHeight
                        
                        self.mainViewHeightConstraint = self.mainView.heightAnchor.constraint(greaterThanOrEqualToConstant: CGFloat(self.mainViewHeight + height))
                        
                        self.shadowViewHeightConstraint = self.shadowview.heightAnchor.constraint(greaterThanOrEqualToConstant: CGFloat(self.shadowViewHeight + height))

                        self.contentViewHeightConstraint.constant = self.shadowViewHeightConstraint.constant
                        
                        self.displayUI()
                    } else {
                        
                        self.eventImageView.image = UIImage.init(named: "default_image")
                        let height = self.imageHeight
                        
                        self.mainViewHeightConstraint.constant = CGFloat(self.mainViewHeight + height)
                        self.shadowViewHeightConstraint.constant = CGFloat(self.shadowViewHeight + height)
                        
                        self.contentViewHeightConstraint.constant = self.shadowViewHeightConstraint.constant
                        self.displayUI()
                    }
                }
                
                
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated);
        
        addCustomNavBar(self, isMenuRequired: false, rightButtonTitle: nil, rightButtonImage: "", title: "Event Details", backhandler: {
            self.navigationController?.popViewController(animated: true)
        }) {
            self.moveToNotification()
        }
    }
    
    @objc func reloadnotificationbar(notification: NSNotification){
        //do stuff
        reloadNavBar(self)
    }
    deinit {
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "ReloadEventDetails"), object: nil)
         NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "ReloadBellIcon"), object: nil)
    }
        
    func moveToNotification() {
        let detailObj = makeStoryObj(storyboard: storyboard_R1, Identifier: "IDNotificationVC") as! NotificationsViewController
        detailObj.isPushVC = true
        pushStoryObj(obj: detailObj, on: self)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        //self.navigationController?.isNavigationBarHidden = false
    }
    
    
    @objc func imageDidLoadNotification(withNotification notification: NSNotification) {
        let height = self.imageHeight
        
        //self.mainViewHeightConstraint.constant = CGFloat(230 + height)
        //self.shadowViewHeightConstraint.constant = CGFloat(240 + height)
        
        self.mainViewHeightConstraint = self.mainView.heightAnchor.constraint(greaterThanOrEqualToConstant: CGFloat(self.mainViewHeight + height))
        
        self.shadowViewHeightConstraint = self.shadowview.heightAnchor.constraint(greaterThanOrEqualToConstant: CGFloat(self.shadowViewHeight + height))
        
        //self.contentSize = self.shadowViewHeightConstraint.constant
        self.contentViewHeightConstraint.constant = self.shadowViewHeightConstraint.constant
        self.getEventDetails()
    }
    
    
    func initSetUp() -> Void {
        happeningTextButton.titleLabel?.textAlignment = .center
        requestTextButton.titleLabel?.textAlignment = .center
        playlistTextButton.titleLabel?.textAlignment = .center
        
        mainView.layer.cornerRadius = 5.0
        mainView.clipsToBounds = true
        //self.contentSize = 0.0
        scrollview.isHidden = true

        /*
        interestedButton.layer.borderColor = UIColor.red.cgColor
        interestedButton.layer.borderWidth = 0.5
        interestedButton.layer.cornerRadius = 3.6
        interestedButton.clipsToBounds = true
        
        artistsButton.layer.borderColor = UIColor.red.cgColor
        artistsButton.layer.borderWidth = 0.5
        artistsButton.layer.cornerRadius = 3.6
        artistsButton.clipsToBounds = true
        */
        
        buttonWidthConstraint.constant = DYNAMICFONTSIZE.SCALE_FACT_FONT * 68;
        buttonHeightConstraint.constant = DYNAMICFONTSIZE.SCALE_FACT_FONT * 68;
        
        self.buttonViewHeightConstraint.constant = (DYNAMICFONTSIZE.SCALE_FACT_FONT * 68) + 70
        
        let eventDetailTapGesturer = UITapGestureRecognizer.init(target: self, action: #selector(openEventDetailsOnFacebook))
        self.peopleCountLabel.addGestureRecognizer(eventDetailTapGesturer)

    }
    
    @IBAction func backClicked(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    //MARK :- Get Event Details
    
    func getEventDetails() {
        GLOBAL().showLoadingIndicatorWithMessage("")
        
        UNTZReqeustManager.sharedInstance.apiGetEventDetails(self.eventId!) {
            (feedResponse) -> Void in
            GLOBAL().hideLoadingIndicator()
            
            if let downloadError = feedResponse.error{
                print(downloadError)
                GLOBAL().showAlert(APPLICATION.applicationName, message: downloadError.localizedDescription, actions: nil)
            } else {
                GLOBAL().hideLoadingIndicator()
                
                if let dictionary = feedResponse.responseDict as? Dictionary<String, AnyObject>{
                    self.eventDetailsResponse = EventDetailsResponse.init(jsonDict:dictionary["data"] as! Dictionary<String, AnyObject>)
                    
                    
                    DispatchQueue.main.async {
                        if self.eventImageURL == nil {
                            self.eventImageURL = self.eventDetailsResponse?.eventInfo?.imageurl
                            self.reloadImageRefresh()
                        } else {
                            self.displayUI()
                        }
                        
                    }
                }
            }
        }
    }
    
    func RSVPStatusManagement() {
        if let RSVPStatusText = GLOBAL.sharedInstance.RSVPStatusText(eventStatus: (eventDetailsResponse?.eventInfo?.eventStatus)!, userName: nil) {
            performingLbl.isHidden = false
            performingLbl.text = RSVPStatusText
            eventTextLabel.isHidden = true
            performingLbl.layer.cornerRadius = 13
            performingLbl.layer.masksToBounds = true
            
            let width = performingLbl.intrinsicContentSize.width
            performingLbl.frame.size = CGSize.init(width: width, height: 26)
            
            //if (eventDetailsResponse?.eventInfo?.islive)! {
                if (eventDetailsResponse?.eventInfo?.isCancelled)! {
                    displayTypeHeightConstraint.constant = 60.0
                } else {
                    displayTypeHeightConstraint.constant = 36.0
                }
            /*} else {
                displayTypeHeightConstraint.constant = 36.0
            }*/
            
        } else {
            eventTextLabel.isHidden = false
            performingLbl.isHidden = true
            displayTypeHeightConstraint.constant = 0.0
            
        }
    }

    func RSVPButtonManagement() {
        let RSVPButton = GLOBAL.sharedInstance.getActionButtonTitleForEventDetails(eventStatus: (eventDetailsResponse?.eventInfo?.eventStatus)!, isCancelled: (eventDetailsResponse?.eventInfo?.isCancelled) ?? false)
        
            if let actionButton1Title = RSVPButton.actionButton1 {
                firstActionImageView.isHidden = false
                interestedButton.isHidden = false
                if actionButton1Title.caseInsensitiveCompare("Interested") == .orderedSame {
                    changeEventFirstButton(buttonTitle: "Interested", buttonImage: "ic_interested_event_details", buttonAction: EventStates.MarkAsInterested)
                }
                else if actionButton1Title.caseInsensitiveCompare("Ignore") == .orderedSame {
                    changeEventFirstButton(buttonTitle: "Ignore", buttonImage: "deleteBtn", buttonAction: EventStates.DeleteEvent)
                }
                else if actionButton1Title.caseInsensitiveCompare("Cancel") == .orderedSame {
                    changeEventFirstButton(buttonTitle: "Cancel", buttonImage: "deleteBtn", buttonAction: EventStates.CancelEvent)
                }
                else if actionButton1Title.caseInsensitiveCompare("Uncancel") == .orderedSame {
                    changeEventFirstButton(buttonTitle: "Uncancel", buttonImage: "undo_cancel", buttonAction: EventStates.UndoCancelEvent)
                }
                else if actionButton1Title.caseInsensitiveCompare("Going") == .orderedSame {
                    changeEventFirstButton(buttonTitle: "Going", buttonImage: "attending", buttonAction: EventStates.AttendingEvent)
                }
                if let actionButton2Title = RSVPButton.actionButton2 {
                    if actionButton2Title.caseInsensitiveCompare("Going") == .orderedSame {
                        changeEventSecondButton(buttonTitle: "Going", buttonImage: "attending", buttonAction: EventStates.AttendingEvent)
                    }
                    else if actionButton2Title.caseInsensitiveCompare("Ignore") == .orderedSame {
                        changeEventSecondButton(buttonTitle: "Ignore", buttonImage: "deleteBtn", buttonAction: EventStates.DeleteEvent)
                    }
                    secondActionButton.isHidden = false
                    secondActionImageView.isHidden = false
                } else {
                    secondActionButton.isHidden = true
                    secondActionImageView.isHidden = true
                }
            } else {
                firstActionImageView.isHidden = true
                interestedButton.isHidden = true
                if RSVPButton.actionButton2 != nil {
                    // this case will never happen
                } else {
                    secondActionButton.isHidden = true
                    secondActionImageView.isHidden = true
                }
            }
    }
    
    func displayUI() {
        RSVPStatusManagement()
        RSVPButtonManagement()
        
        if(eventDetailsResponse?.eventInfo?.islive)! {
            self.getCurrentlyPlayingTrack()
        }
        
        self.eventNameLabel.text = self.eventDetailsResponse?.eventInfo?.eventName
        self.eventTypeLabel.text = self.eventDetailsResponse?.eventInfo?.category?.replacingOccurrences(of: "_", with: " ")
        self.timeLabel.text = self.eventDetailsResponse?.eventInfo?.dateTimeStart
        
            self.placeLable.text = String.init(format: "%@", (self.eventDetailsResponse?.eventInfo?.eventLocation?.locationName)!)
        
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ" //Your date format //yyyy-MM-dd'T'HH:mm:ss-mm:ss
        dateFormatter.timeZone = NSTimeZone(name: "PT") as TimeZone!
        let date = dateFormatter.date(from: (self.eventDetailsResponse?.eventInfo?.dateTimeStart)!) //according to date format your date string
        if self.eventDetailsResponse?.eventInfo?.dateTimeEnd != nil {
            let endDate = dateFormatter.date(from: (self.eventDetailsResponse?.eventInfo?.dateTimeEnd)!) //according to date
            if (endDate != nil && date != nil){
                dateFormatter.dateFormat = "EEE h:mm a"
                let dateName = dateFormatter.string(from: date!)
                
                dateFormatter.dateFormat = "h:mm a"
                let endDateName = dateFormatter.string(from: endDate!)
                self.timeLabel.text = String.init(format: "%@ - %@", dateName,endDateName)
                
            }
            else{
                self.timeLabel.text = ""
            }
        }
        else if (date != nil){
            dateFormatter.dateFormat = "EEE h:mm a"
            let dateName = dateFormatter.string(from: date!)
            self.timeLabel.text = dateName
        }
        
        if (date != nil){
            dateFormatter.dateFormat = "MMM"
            let monthName = dateFormatter.string(from: date!)
            self.dateMonthLabel.text = monthName
            
            dateFormatter.dateFormat = "dd"
            let datefmt = dateFormatter.string(from: date!)
            self.dateDayLabel.text = datefmt
            
        }  else{
            self.dateMonthLabel.text = ""
            self.dateDayLabel.text = ""
        }
        
        self.hostedByLabel.numberOfLines = 0
        let eventAdminName : NSMutableAttributedString = NSMutableAttributedString.init(string: "")
        var charactersArray: [String] = []
        var adminCharactersArray: [NSAttributedString] = []
        var nonAdminCharactersArray: [NSAttributedString] = []
        
        for eventAdmin in (self.eventDetailsResponse?.eventInfo?.eventAdminsArray)! {
            if let accountId = eventAdmin.adminAccountId {
                let adminName = NSAttributedString.init(string: eventAdmin.adminName!, attributes: [NSFontAttributeName : UIFont(name: "Roboto-Medium", size: 16.0)!, NSForegroundColorAttributeName:UIColor.black])
                adminCharactersArray.append(adminName)
                eventAdminName.append(adminName)
                charactersArray.append(eventAdmin.adminName!)
                eventAdminName.append(NSAttributedString.init(string: ", "))
                print(accountId)
            } else {
                let nonadminName = NSAttributedString.init(string: eventAdmin.adminName!, attributes: [NSFontAttributeName : UIFont(name: "Roboto-Regular", size: 16.0)!, NSForegroundColorAttributeName:UIColor.black])
                nonAdminCharactersArray.append(nonadminName)
                eventAdminName.append(nonadminName)
                eventAdminName.append(NSAttributedString.init(string: ", "))
            }
        }
        
        let truncatedName = eventAdminName.string.dropLast()
        let truncatedEventAdminName = String(truncatedName.dropLast())
        let hostedEventAdminNames = String.init(format: "Hosted By %@", truncatedEventAdminName)
        
        self.hostedByLabel.text = String.init(format: "Hosted By %@", truncatedEventAdminName)
        
        hostedByLabel.delegate = self
        let color = UIColor.init(red: 28/255.0, green: 135/255.0, blue: 199/255.0, alpha: 1.0)
        hostedByLabel.linkAttributes = [NSFontAttributeName : UIFont(name: "Roboto-Medium", size: 16.0)!, NSForegroundColorAttributeName:color]
        
        for char in charactersArray {
            
            //Step 3: Add link substrings
            //self.hostedByLabel.linkAttributeDefault = [NSFontAttributeName : UIFont(name: "Roboto-Medium", size: 16.0)!, NSForegroundColorAttributeName:color]
            //self.hostedByLabel.setLinksForSubstrings(charactersArray, withLinkHandler: handler)
            let rangeWord = hostedEventAdminNames.range(of: char)
            let nsRange = NSRange(rangeWord!, in: char)
            self.hostedByLabel.isUserInteractionEnabled = true
            hostedByLabel.addLink(to: URL(string: char.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!), with:nsRange)
            
        }
        
        
        //let eventAdminNameFinal = NSAttributedString.init(string: hostedEventAdminNames, attributes: [NSFontAttributeName : UIFont(name: "Roboto-Regular", size: 16.0)!, NSForegroundColorAttributeName:UIColor.black])

        //self.hostedByLabel.attributedText = eventAdminNameFinal
        
        //Step 2: Define a selection handler block
        //let handler = {
          //  (hyperLabel: FRHyperLabel?, substring: String?) -> Void in
           // self.openEventDetailsOnFacebookNew(strName: substring!)
        //}
        //let color = UIColor.init(red: 28/255.0, green: 135/255.0, blue: 199/255.0, alpha: 1.0)
        //Step 3: Add link substrings
        //self.hostedByLabel.linkAttributeDefault = [NSFontAttributeName : UIFont(name: "Roboto-Medium", size: 16.0)!, NSForegroundColorAttributeName:color]
        //self.hostedByLabel.setLinksForSubstrings(charactersArray, withLinkHandler: handler)
        //self.hostedByLabel.isUserInteractionEnabled = true
        
        /*
        for char in charactersArray {
            let color = UIColor.init(red: 28/255.0, green: 135/255.0, blue: 199/255.0, alpha: 1.0)
            //Step 3: Add link substrings
            self.hostedByLabel.linkAttributeDefault = [NSFontAttributeName : UIFont(name: "Roboto-Medium", size: 16.0)!, NSForegroundColorAttributeName:color]
            //self.hostedByLabel.setLinksForSubstrings(charactersArray, withLinkHandler: handler)
            //let rangeWord = hostedEventAdminNames.range(of: char)
            let nsRange = NSRange(rangeWord!, in: char)
            //self.hostedByLabel.setLinkFor(nsRange, withLinkHandler: { (label, range) in
             //   print(label?.text)
             //   print(range)
            //})
            self.hostedByLabel.isUserInteractionEnabled = true
        }
        */
        
        self.peopleCountLabel.text = String.init(format: "%ld Attending | %ld Interested", (self.eventDetailsResponse?.eventInfo?.facebookAttendingCount)!,(self.eventDetailsResponse?.eventInfo?.facebookInterestedCount)!)
        
        if UserInfo.sharedInstance.getUserDefault(key: UNUserInfoKeys.accessToken) != nil {
            
            if (eventDetailsResponse?.eventInfo?.eventStatus?.isUserArtist)! || (eventDetailsResponse?.eventInfo?.eventStatus?.isUserInterested)! || (eventDetailsResponse?.eventInfo?.eventStatus?.isUserJoined)! || (eventDetailsResponse?.eventInfo?.eventStatus?.isUserAdmin)! {
                userdisplayView.isHidden = false
                
                
//                self.contentSize = self.contentSize! + self.displayTypeHeightConstraint.constant

                if (eventDetailsResponse?.eventInfo?.eventStatus?.isUserAdmin)! {
                    //if (eventDetailsResponse?.eventInfo?.islive)! {
                        if (eventDetailsResponse?.eventInfo?.isCancelled)! {
                            performTimeLbl.isHidden = false
                            eventTextLabel.isHidden = true

                            performTimeLbl.text = "This Event Has Been Cancelled!"
                            /*
                            interestedButton.setTitle("UNDO CANCEL", for: UIControlState.normal)
                            interestedButton .setImage(UIImage.init(named: "undo_cancel"), for: UIControlState.normal)
                            interestedButton.tag = EventStates.UndoCancelEvent.rawValue
                            */
                        } else {
                            performingLbl.isHidden = false
                            performTimeLbl.isHidden = true
                            eventTextLabel.isHidden = true

                            //performTimeLbl.text = timediffernce()
                            /*
                            interestedButton.setTitle("CANCEL", for: UIControlState.normal)
                            interestedButton .setImage(UIImage.init(named: "cancel_event"), for: UIControlState.normal)
                            interestedButton.tag = EventStates.CancelEvent.rawValue
                            */
                        }
                        
                    /*} else {
                        performingLbl.isHidden = false
                        performTimeLbl.isHidden = true
                        eventTextLabel.isHidden = true

                        /*
                        interestedButton .setTitle("GO LIVE", for: UIControlState.normal)
                        interestedButton .setImage(UIImage.init(named: "go_live"), for: UIControlState.normal)
                        interestedButton.tag = EventStates.MakeItLive.rawValue
                        */
                    }*/
                } else {
                    if (eventDetailsResponse?.eventInfo?.eventStatus?.isUserInterested)! {
                        if (eventDetailsResponse?.eventInfo?.islive)! {
                            if (eventDetailsResponse?.eventInfo?.eventStatus?.isUserJoined)! {
                                performingLbl.isHidden = false
                                performTimeLbl.isHidden = true
                                eventTextLabel.isHidden = true
                                
                                //performTimeLbl.text = timediffernce()
                                
                                /*
                                interestedButton.setTitle("LEAVE", for: UIControlState.normal)
                                interestedButton .setImage(UIImage.init(named: "leave_event"), for: UIControlState.normal)
                                interestedButton.tag = EventStates.LeaveEvent.rawValue
                                */
                                
                            } else {
                                performingLbl.isHidden = false
                                performTimeLbl.isHidden = true
                                eventTextLabel.isHidden = true
                                
                                //performTimeLbl.text = timediffernce()
                                //performingLbl.text = "You are Interested"
                                
                                /*
                                interestedButton .setTitle("JOIN", for: UIControlState.normal)
                                interestedButton .setImage(UIImage.init(named: "join_event"), for: UIControlState.normal)
                                interestedButton.tag = EventStates.JoinEvent.rawValue
                                 */
                            }
                        } else {
                            performingLbl.isHidden = true
                            performTimeLbl.isHidden = true
                            eventTextLabel.isHidden = true
                            
                            /*
                            interestedButton.setTitle("REMOVE", for: UIControlState.normal)
                            interestedButton .setImage(UIImage.init(named: "delete"), for: UIControlState.normal)
                            interestedButton.tag = EventStates.DeleteEvent.rawValue
                             */
                        }
                        
                        
                    } else {
                        eventTextLabel.isHidden = false
                        
                        /*
                        interestedButton .setTitle("INTERESTED", for: UIControlState.normal)
                        interestedButton .setImage(UIImage.init(named: "interested_event"), for: UIControlState.normal)
                        interestedButton.tag = EventStates.MarkAsInterested.rawValue
                        */
                    }
                }
                
                
                if (eventDetailsResponse?.eventInfo?.eventStatus?.isUserArtist)! {
                    //performingLbl.isHidden = false
                    //performTimeLbl.text = "You are performming!"
                    //performTimeLbl.text = timediffernce()
                }
                
                eventTextLabel.isHidden = true
            } else {
                eventTextLabel.isHidden = false
                
                /*
                interestedButton .setTitle("INTERESTED", for: UIControlState.normal)
                interestedButton .setImage(UIImage.init(named: "interested_event"), for: UIControlState.normal)
                interestedButton.tag = EventStates.MarkAsInterested.rawValue
                */
            }
            
            
        } else {
            eventTextLabel.isHidden = false
        }
        
        performingLbl.isHidden = false
        eventTextLabel.isHidden = true
        
        manageConstraints()
    }
    
    func manageConstraints() {
        self.mainViewHeightConstraint = self.mainView.heightAnchor.constraint(greaterThanOrEqualToConstant: CGFloat(self.imageHeight + self.mainViewHeight))
        
        let contentHeight : CGFloat = (self.hostedByLabel.text?.contentHeight(withConstrainedWidth: self.hostedByLabel.frame.size.width, font: self.hostedByLabel.font)) ?? 20.0
        
        self.shadowViewHeightConstraint = self.shadowview.heightAnchor.constraint(greaterThanOrEqualToConstant: CGFloat(self.imageHeight + self.shadowViewHeight))
        
        self.contentViewHeightConstraint.constant = self.shadowViewHeightConstraint.constant + self.buttonViewHeightConstraint.constant +
            contentHeight + self.displayTypeHeightConstraint.constant
        
        self.scrollview.isHidden = false
        self.view.layoutIfNeeded()
    }
    
    func getCurrentlyPlayingTrack() {
        //GLOBAL().showLoadingIndicatorWithMessage("")
        
        UNTZReqeustManager.sharedInstance.apiGetCurrentlyPlayingTrack(self.eventId!) { (feedResponse) -> Void in
            //GLOBAL().hideLoadingIndicator()
            
            if let downloadError = feedResponse.error {
                print(downloadError)
                GLOBAL().showAlert(APPLICATION.applicationName, message: downloadError.localizedDescription, actions: nil)
            } else {
                //GLOBAL().hideLoadingIndicator()
                
                if let dictionary = feedResponse.responseDict as? Dictionary<String, AnyObject> {
                    print(dictionary)
                    if let dataDict = dictionary["data"] as? Dictionary<String,AnyObject> {
                        self.displayLiveSong(dataDict)
                    }
                    
                }
            }
        }
    }

    func displayLiveSong(_ data: Dictionary<String, AnyObject>) -> Void {
        let curretntlyEventPlayingTrack = data["EventPlaylistTrack"] as! Dictionary<String,AnyObject>
        
        let songName = curretntlyEventPlayingTrack["spotifyTrackName"] as! String
        let imagePath = curretntlyEventPlayingTrack["spotifyAlbumImageUri"] as! String
        let artistsArray = curretntlyEventPlayingTrack["eventTrackArtists"] as! Array<Dictionary<String,AnyObject>>
        
        let artistDict = artistsArray[0] 
        let artistNameValue = artistDict["name"] as! String
        
        songTitle.text = songName
        artistName.text = artistNameValue
        
        songImageView.layer.cornerRadius = profileImageview.frame.size.height/2
        songImageView.clipsToBounds = true

        songImageView.sd_setImage(with: URL.init(string: imagePath))
        
        UIView.animate(withDuration: 0.5, animations: {
            self.userdisplayView.isHidden = false
            self.currentSongPlayingHeightConstraint.constant = 70
            self.view.layoutIfNeeded()
        })
        
    }
    //MARK :- Mark Event as Interested Or Not
    
    func markEventAsInterested(_ interested : Bool) {
        GLOBAL().showLoadingIndicatorWithMessage("")
        
        UNTZReqeustManager.sharedInstance.apiMarkEventAsInterestedOrNot(self.eventId!, isInterested: interested) {
            (feedResponse) -> Void in
            GLOBAL().hideLoadingIndicator()
            
            if let downloadError = feedResponse.error{
                print(downloadError)
                GLOBAL().showAlert(APPLICATION.applicationName, message: downloadError.localizedDescription, actions: nil)
            } else {
                GLOBAL().hideLoadingIndicator()
                
                if let dictionary = feedResponse.responseDict as? Dictionary<String, AnyObject>{
                    //self.eventDetailsResponse = EventDetailsResponse.init(jsonDict:dictionary)
                    print("\(dictionary)")
                    
                    if let data = dictionary["data"] as? Dictionary<String, AnyObject> {
                        if let success = data["success"] as? Bool {
                            if success == true {
                                if let updatedEvent = data["updatedEvent"] as? Dictionary<String, AnyObject> {
                                    
                                    
                                    let eventsInfo = EventInfo.init(jsonDict: updatedEvent)
                                    
                                      let updateDataDict:[String: EventInfo] = ["eventInfo": eventsInfo]
                                    
                                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshHomeEvents"), object: self, userInfo: updateDataDict)
                                    
                                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshUpcomingEvents"), object: self, userInfo: updateDataDict)
                                   
                                   /* self.eventDetailsResponse?.eventInfo?.eventStatus?.isUserInterested = interested
                                    
                                    if interested {
                                        self.eventDetailsResponse?.eventInfo?.eventStatus?.rsvpStatus = "interested"
                                    } else {
                                        self.eventDetailsResponse?.eventInfo?.eventStatus?.rsvpStatus = nil
                                    }
 
                                    
                                    self.changeViewToInterested()
                                    */
                                    
                                    self.eventDetailsResponse?.replaceNewEventInfo(eventInfoDict: updatedEvent)

                                    DispatchQueue.main.async {
                                        self.displayUI()
                                    }
                                }
                            } else {
                                GLOBAL().showAlert(APPLICATION.applicationName, message: "There was an error processing your request!", actions: nil)
                            }
                        } else {
                            GLOBAL().showAlert(APPLICATION.applicationName, message: "There was an error processing your request!", actions: nil)
                        }
                    } else {
                        GLOBAL().showAlert(APPLICATION.applicationName, message: "There was an error processing your request!", actions: nil)
                    }
                
                    
                    /*
                    let dataValue = dictionary["data"] as! Bool!
                    
                    if dataValue == true {
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "UpdateHomeScreen"), object: self)
                        self.eventDetailsResponse?.eventInfo?.eventStatus?.isUserInterested = interested
                        
                        if interested {
                          self.eventDetailsResponse?.eventInfo?.eventStatus?.rsvpStatus = "interested"
                        } else {
                            self.eventDetailsResponse?.eventInfo?.eventStatus?.rsvpStatus = nil
                        }
                            
                        self.changeViewToInterested()
                        
                    } else {
                        GLOBAL().showAlert(APPLICATION.applicationName, message: "There was an error processing your request!", actions: nil)
                    }
                     */
                }
            }
        }
    }
    
    //MARK :- Mark Event as Canceled Or Not
    
    func markEventAsCanceledOrNot(_ isCancelled : Bool) {
        GLOBAL().showLoadingIndicatorWithMessage("")
        
        UNTZReqeustManager.sharedInstance.apiMarkEventAsCanceledOrNot(self.eventId!, isCancelled: isCancelled) {
            (feedResponse) -> Void in
            GLOBAL().hideLoadingIndicator()
            
            if let downloadError = feedResponse.error{
                print(downloadError)
                GLOBAL().showAlert(APPLICATION.applicationName, message: downloadError.localizedDescription, actions: nil)
            } else {
                GLOBAL().hideLoadingIndicator()
                
                if let dictionary = feedResponse.responseDict as? Dictionary<String, AnyObject>{
                    print("\(dictionary)")
                    
                    if let data = dictionary["data"] as? Dictionary<String, AnyObject> {
                        
                        if let success = data["success"] as? Bool {
                            if success == true {
                                if let updatedEvent = data["updatedEvent"] as? Dictionary<String, AnyObject> {
                                    let eventsInfo = EventInfo.init(jsonDict: updatedEvent)
                                    
                                    let updateDataDict:[String: EventInfo] = ["eventInfo": eventsInfo]
                                    
                                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshHomeEvents"), object: self, userInfo: updateDataDict)
                                    
                                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshUpcomingEvents"), object: self, userInfo: updateDataDict)

                                    
                                    //self.eventDetailsResponse?.eventInfo?.isCancelled = isCancelled
                                    //self.changeViewToLiveOrCancel()
                                    
                                    self.eventDetailsResponse?.replaceNewEventInfo(eventInfoDict: updatedEvent)
                                    
                                    DispatchQueue.main.async {
                                        self.displayUI()
                                    }
                                }
                            } else {
                                GLOBAL().showAlert(APPLICATION.applicationName, message: "There was an error processing your request!", actions: nil)
                            }
                        } else {
                            GLOBAL().showAlert(APPLICATION.applicationName, message: "There was an error processing your request!", actions: nil)
                        }
                    } else {
                        GLOBAL().showAlert(APPLICATION.applicationName, message: "There was an error processing your request!", actions: nil)
                    }
                }
            }
        }
    }

    // MARK: Mark Event as Go Live
    
    func goLiveEvent() {
        GLOBAL().showLoadingIndicatorWithMessage("")
        
        UNTZReqeustManager.sharedInstance.apiGoLiveEvent(self.eventId!) {
            (feedResponse) -> Void in
            GLOBAL().hideLoadingIndicator()
            
            if let downloadError = feedResponse.error{
                print(downloadError)
                GLOBAL().showAlert(APPLICATION.applicationName, message: downloadError.localizedDescription, actions: nil)
            } else {
                GLOBAL().hideLoadingIndicator()
                
                if let dictionary = feedResponse.responseDict as? Dictionary<String, AnyObject>{
                    let dataValue = dictionary["data"] as! Bool!
                    
                    if dataValue == true {
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "UpdateHomeScreen"), object: self)
                        self.eventDetailsResponse?.eventInfo?.islive = true
                        self.changeViewToLiveOrCancel()
                    } else {
                        GLOBAL().showAlert(APPLICATION.applicationName, message: "There was an error processing your request!", actions: nil)
                    }

                }
            }
        }
    }

    //MARK: Join Event or Leave Event
    
    func joinOrLeaveEvent(_ isLeaving : Bool) {
        GLOBAL().showLoadingIndicatorWithMessage("")
        
        UNTZReqeustManager.sharedInstance.apiJoinOrLeaveEvent(self.eventId!, isLeaving: isLeaving) {
            (feedResponse) -> Void in
            GLOBAL().hideLoadingIndicator()
            
            if let downloadError = feedResponse.error{
                print(downloadError)
                GLOBAL().showAlert(APPLICATION.applicationName, message: downloadError.localizedDescription, actions: nil)
            } else {
                GLOBAL().hideLoadingIndicator()
                
                if let dictionary = feedResponse.responseDict as? Dictionary<String, AnyObject>{
                    print("\(dictionary)")
                    
                    let dataValue = dictionary["data"] as! Bool!
                    
                    if dataValue == true {
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "UpdateHomeScreen"), object: self)
                        self.eventDetailsResponse?.eventInfo?.eventStatus?.isUserJoined = !isLeaving
                        
                        if isLeaving {
                            self.eventDetailsResponse?.eventInfo?.eventStatus?.rsvpStatus = "interested"
                        } else {
                            self.eventDetailsResponse?.eventInfo?.eventStatus?.rsvpStatus = "joined"
                        }
                        
                        self.changeViewToJoinOrLeave()
                    } else {
                        GLOBAL().showAlert(APPLICATION.applicationName, message: "There was an error processing your request!", actions: nil)
                    }

                }
            }
        }
    }

    @IBAction func interestedButtonEvent(_ sender: UIButton) {
        let eventStateValue = sender.tag as Int!
        
        firstActionEventAPI(eventStateValue: eventStateValue!)
    }

    func firstActionEventAPI(eventStateValue : Int) {
        if UserInfo.sharedInstance.getUserDefault(key: UNUserInfoKeys.accessToken) != nil {
            
            if (eventStateValue == EventStates.MarkAsInterested.rawValue || eventStateValue == EventStates.DeleteEvent.rawValue) {
                markAsInterestedEvent()
            } /*else if (eventStateValue == EventStates.JoinEvent.rawValue || eventStateValue == EventStates.LeaveEvent.rawValue) {
                 joinEventPlatform()
             } */ else if (eventStateValue == EventStates.MakeItLive.rawValue || eventStateValue == EventStates.CancelEvent.rawValue || eventStateValue == EventStates.UndoCancelEvent.rawValue) {
                liveEventPlatform()
            } else if (eventStateValue == EventStates.AttendingEvent.rawValue) {
                markAsAttendEvent()
            }
            
        }else {
            //GLOBAL().showAlert(APPLICATION.applicationName, message: "Login to mark as Interested!", actions: nil)
            FacebookLoginManager.sharedInstance.startLoginProcess(viewController: self, isFromEventDetails: true)
        }
        
    }
    
    @IBAction func secondActionButtonEvent(_ sender: UIButton) {
        let eventStateValue = sender.tag as Int!
        
        secondActionEventAPI(eventStateValue: eventStateValue!)
    }
    
    func secondActionEventAPI(eventStateValue : Int) {
        if UserInfo.sharedInstance.getUserDefault(key: UNUserInfoKeys.accessToken) != nil {
            if (eventStateValue == EventStates.AttendingEvent.rawValue) {
                markAsAttendEvent()
            } else if (eventStateValue == EventStates.MarkAsInterested.rawValue || eventStateValue == EventStates.DeleteEvent.rawValue) {
                markAsInterestedEvent()
            }
            else {
                FacebookLoginManager.sharedInstance.startLoginProcess(viewController: self, isFromEventDetails: true)
            }
        }
        else {
            FacebookLoginManager.sharedInstance.startLoginProcess(viewController: self, isFromEventDetails: true)
        }

    }
    
    func markAsAttendEvent() {
        GLOBAL().showLoadingIndicatorWithMessage("")
        
        UNTZReqeustManager.sharedInstance.apiAttendingEvent(self.eventId!) {
            (feedResponse) -> Void in
            GLOBAL().hideLoadingIndicator()
            
            if let downloadError = feedResponse.error{
                print(downloadError)
                GLOBAL().showAlert(APPLICATION.applicationName, message: downloadError.localizedDescription, actions: nil)
            } else {
                GLOBAL().hideLoadingIndicator()
                
                if let dictionary = feedResponse.responseDict as? Dictionary<String, AnyObject>{
                    print("\(dictionary)")
                    
                    if let data = dictionary["data"] as? Dictionary<String, AnyObject> {
                        if let success = data["success"] as? Bool {
                            if success == true {
                                if let updatedEvent = data["updatedEvent"] as? Dictionary<String, AnyObject> {
                                    
                                    
                                    let eventsInfo = EventInfo.init(jsonDict: updatedEvent)
                                    
                                    let updateDataDict:[String: EventInfo] = ["eventInfo": eventsInfo]
                                    
                                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshHomeEvents"), object: self, userInfo: updateDataDict)
                                    
                                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshUpcomingEvents"), object: self, userInfo: updateDataDict)

                                    
                                    self.eventDetailsResponse?.replaceNewEventInfo(eventInfoDict: updatedEvent)
                                    
                                    DispatchQueue.main.async {
                                        self.displayUI()
                                    }
                                }
                            } else {
                                GLOBAL().showAlert(APPLICATION.applicationName, message: "There was an error processing your request!", actions: nil)
                            }
                        } else {
                            GLOBAL().showAlert(APPLICATION.applicationName, message: "There was an error processing your request!", actions: nil)
                        }
                    } else {
                        GLOBAL().showAlert(APPLICATION.applicationName, message: "There was an error processing your request!", actions: nil)
                    }
                }
            }
        }
    }
    
    func markAsInterestedEvent() {
        if UserInfo.sharedInstance.getUserDefault(key: UNUserInfoKeys.accessToken) != nil {
            if (eventDetailsResponse?.eventInfo?.eventStatus?.isUserInterested)! {
                markEventAsInterested(false)
                //performingLbl.isHidden = true
                //performTimeLbl.isHidden = true
                //eventTextLabel.isHidden = true
                //interestedButton .setTitle("REMOVE", for: UIControlState.normal)
                //interestedButton .setImage(UIImage.init(named: "delete"), for: UIControlState.normal)
            } else {
                markEventAsInterested(true)
                //performingLbl.isHidden = false
                //performTimeLbl.isHidden = false
                //eventTextLabel.isHidden = false
                //interestedButton .setTitle("INTERESTED", for: UIControlState.normal)
                //interestedButton .setImage(UIImage.init(named: "interested_event"), for: UIControlState.normal)
            }
        } else {
            //GLOBAL().showAlert(APPLICATION.applicationName, message: "Login to mark as Interested!", actions: nil)
            FacebookLoginManager.sharedInstance.startLoginProcess(viewController: self, isFromEventDetails: true)
        }
    }
    
    // MARK: LIVE Event Platform
    
    func liveEventPlatform() {
        if UserInfo.sharedInstance.getUserDefault(key: UNUserInfoKeys.accessToken) != nil {
            //if (eventDetailsResponse?.eventInfo?.islive)! {
                if (eventDetailsResponse?.eventInfo?.isCancelled)! {
                    markEventAsCanceledOrNot(false)
                } else {
                    markEventAsCanceledOrNot(true)
                }
                
//                interestedButton.setTitle("LIVE", for: UIControlState.normal)
//                interestedButton .setImage(UIImage.init(named: "go_live"), for: UIControlState.normal)
            //} else {
              //  goLiveEvent()
//                interestedButton.setTitle("CANCEL", for: UIControlState.normal)
//                interestedButton .setImage(UIImage.init(named: "cancel_event"), for: UIControlState.normal)
            //}
        } else {
            GLOBAL().showAlert(APPLICATION.applicationName, message: "You are not admin!", actions: nil)
            
        }
    }
    
    // MARK: JOIN Event Platform
    func joinEventPlatform() {
        if UserInfo.sharedInstance.getUserDefault(key: UNUserInfoKeys.accessToken) != nil {
            if (eventDetailsResponse?.eventInfo?.eventStatus?.isUserJoined)! {
                joinOrLeaveEvent(true)
                //interestedButton.setTitle("LEAVE", for: UIControlState.normal)
                //interestedButton .setImage(UIImage.init(named: "leave_event"), for: UIControlState.normal)
            } else {
                joinOrLeaveEvent(false)
                //interestedButton.setTitle("JOIN", for: UIControlState.normal)
                //interestedButton .setImage(UIImage.init(named: "join_event"), for: UIControlState.normal)
            }
        } else {
            //GLOBAL().showAlert(APPLICATION.applicationName, message: "Login to Join Event!", actions: nil)
            FacebookLoginManager.sharedInstance.startLoginProcess(viewController: self, isFromEventDetails: true)
        }
    }
    
    // MARK: Change View To Interested
    func changeViewToInterested () {
        if UserInfo.sharedInstance.getUserDefault(key: UNUserInfoKeys.accessToken) != nil {
            if (eventDetailsResponse?.eventInfo?.eventStatus?.isUserInterested)! {

                performingLbl.isHidden = false
                performTimeLbl.isHidden = true
                
                RSVPStatusManagement()
                manageConstraints()
                
                //interestedButton.setTitle("REMOVE", for: UIControlState.normal)
                //interestedButton .setImage(UIImage.init(named: "delete"), for: UIControlState.normal)
                
                UIView.animate(withDuration: 1.0, animations: {
                    self.userdisplayView.isHidden = false
                    self.view.layoutIfNeeded()
                })

            } else {
                performingLbl.isHidden = true
                performTimeLbl.isHidden = true

                RSVPStatusManagement()
                manageConstraints()
                
                //interestedButton .setTitle("INTERESTED", for: UIControlState.normal)
                //interestedButton .setImage(UIImage.init(named: "interested_event"), for: UIControlState.normal)
                
                UIView.animate(withDuration: 1.0, animations: {
                    self.userdisplayView.isHidden = true
                    
                    self.view.layoutIfNeeded()
                })

            }
        } else {
            userdisplayView.isHidden = true
        }

    }

    // MARK: Change View To Join Or Leave
    func changeViewToJoinOrLeave () {
        if UserInfo.sharedInstance.getUserDefault(key: UNUserInfoKeys.accessToken) != nil {
            if (eventDetailsResponse?.eventInfo?.islive)! {
                if (eventDetailsResponse?.eventInfo?.eventStatus?.isUserJoined)! {
                    performingLbl.isHidden = false
                    performTimeLbl.isHidden = false
                    
                    
                    performTimeLbl.text = timediffernce()

                    RSVPStatusManagement()
                    manageConstraints()

                    //interestedButton.setTitle("LEAVE", for: UIControlState.normal)
                    //interestedButton .setImage(UIImage.init(named: "leave_event"), for: UIControlState.normal)
                    //interestedButton.tag = EventStates.LeaveEvent.rawValue

                UIView.animate(withDuration: 1.0, animations: {
                    self.userdisplayView.isHidden = false
                    self.view.layoutIfNeeded()
                })
                }
            } else {
                performingLbl.isHidden = false
                performTimeLbl.isHidden = false
                
                performTimeLbl.text = timediffernce()
                
                //performingLbl.text = "   You are interested   "
                
                RSVPStatusManagement()
                manageConstraints()

                //interestedButton .setTitle("JOIN", for: UIControlState.normal)
                //interestedButton .setImage(UIImage.init(named: "join_event"), for: UIControlState.normal)
                //interestedButton.tag = EventStates.JoinEvent.rawValue
                
                UIView.animate(withDuration: 1.0, animations: {
                    self.userdisplayView.isHidden = true
                    
                    self.view.layoutIfNeeded()
                })
                
            }
        } else {
            userdisplayView.isHidden = true
        }
        
    }

    // MARK: Change View To Live And Cancel
    func changeViewToLiveOrCancel () {
        if UserInfo.sharedInstance.getUserDefault(key: UNUserInfoKeys.accessToken) != nil {
            if (eventDetailsResponse?.eventInfo?.eventStatus?.isUserAdmin)! {
                if (eventDetailsResponse?.eventInfo?.islive)! {
                    if (eventDetailsResponse?.eventInfo?.isCancelled)! {
                        performingLbl.isHidden = false
                        performTimeLbl.isHidden = false
                        //performingLbl.text = "You are Hosting"
                        performTimeLbl.text = "This Event Has Been Cancelled!"
                        //eventTextLabel.isHidden = true
                        
                        RSVPStatusManagement()
                        manageConstraints()

                        
                        //interestedButton.setTitle("UNDO CANCEL", for: UIControlState.normal)
                        //interestedButton .setImage(UIImage.init(named: "undo_cancel"), for: UIControlState.normal)
                        //interestedButton.tag = EventStates.UndoCancelEvent.rawValue
                        
                    } else {
                        performingLbl.isHidden = false
                        performTimeLbl.isHidden = false

                        //performingLbl.text = "You are Hosting"
                        performTimeLbl.text = timediffernce()
                        
                        RSVPStatusManagement()
                        manageConstraints()

                        //interestedButton.setTitle("CANCEL", for: UIControlState.normal)
                        //interestedButton .setImage(UIImage.init(named: "cancel_event"), for: UIControlState.normal)
                        //interestedButton.tag = EventStates.CancelEvent.rawValue
                        
                    }
                    
                } else {
                    //eventTextLabel.isHidden = true
                    performingLbl.isHidden = false
                    //performingLbl.text = "You are Hosting"
                    
                    RSVPStatusManagement()
                    manageConstraints()

                    
                    //interestedButton .setTitle("GO LIVE", for: UIControlState.normal)
                    //interestedButton .setImage(UIImage.init(named: "go_live"), for: UIControlState.normal)
                    //interestedButton.tag = EventStates.MakeItLive.rawValue
                }
            }
        } else {
            userdisplayView.isHidden = true
        }
        
    }

    
    func openEventDetailsOnFacebook()  {
        let facebookEventURL = String.init(format: "https://www.facebook.com/%@", (eventDetailsResponse?.eventInfo?.facebookid)!)
        if UIApplication.shared.canOpenURL(URL.init(string: facebookEventURL)!) {
            if #available(iOS 10.0, *) {
                UIApplication.shared.open((URL.init(string: facebookEventURL)!), options: [:], completionHandler: nil)
            } else {
                // Fallback on earlier versions
                UIApplication.shared.openURL(URL.init(string: facebookEventURL)!)
            }
        }
    }
    func openEventDetailsOnFacebookNew(strName :String)  {
        
        var eventadminid : Int?
        
        for eventAdmin in (self.eventDetailsResponse?.eventInfo?.eventAdminsArray)! {
            if eventAdmin.adminName == strName{
                if let adminAccountId = eventAdmin.adminAccountId {
                    eventadminid = adminAccountId
                }
            }
        }
        
        if let eventadminid = eventadminid {
            let detailObj = makeStoryObj(storyboard: storyboard_R1, Identifier: "IDProfileVC") as! ProfileViewController
            
            let defaults = UserDefaults.standard
            let accountId = defaults.integer(forKey: UNUserInfoKeys.accountID)
            
            if(eventadminid ==  accountId) {
                detailObj.isFanProfile = false
                detailObj.userID = String.init(format: "%ld", accountId)
            } else {
                detailObj.isFanProfile = true
                detailObj.userID = String.init(format: "%ld", eventadminid)
            }
            pushStoryObj(obj: detailObj, on: self)
        }
        
        
        /*
        let facebookEventURL = String.init(format: "https://www.facebook.com/%@", eventadminid)
        //(eventDetailsResponse?.eventInfo?.facebookid)!
        if UIApplication.shared.canOpenURL(URL.init(string: facebookEventURL)!) {
            if #available(iOS 10.0, *) {
                UIApplication.shared.open((URL.init(string: facebookEventURL)!), options: [:], completionHandler: nil)
            } else {
                // Fallback on earlier versions
                UIApplication.shared.openURL(URL.init(string: facebookEventURL)!)
            }
        }*/
        
    }
    
    @IBAction func whatsHappeningButtonEvent(_ sender: Any) {
        if UserInfo.sharedInstance.getUserDefault(key: UNUserInfoKeys.accessToken) != nil {
            let detailObj = makeStoryObj(storyboard: EventModuleStoryboard, Identifier: "IDFeedPostVC") as! FeedPostViewController
            detailObj.eventId = eventId
            pushStoryObj(obj: detailObj, on: self)
        }
        else {
            //GLOBAL().showAlert(APPLICATION.applicationName, message: "Login to join the conversation!", actions: nil)
            FacebookLoginManager.sharedInstance.startLoginProcess(viewController: self, isFromEventDetails: true)
        }
    }
    
    @IBAction func requestsButtonEvent(_ sender: Any) {
        if UserInfo.sharedInstance.getUserDefault(key: UNUserInfoKeys.accessToken) != nil {
            let detailObj = makeStoryObj(storyboard: PlaylistStoryboard, Identifier: "IDUNTrackRequestsVC") as! UNTrackRequestsVC
            detailObj.eventId = eventId
            
            var showPlaylist : Bool? = false
            if let eventStatus =  (eventDetailsResponse?.eventInfo?.eventStatus) {
                
                
                if eventStatus.isUserAdmin || eventStatus.isUserArtist {
                    showPlaylist = true
                } else {
                    showPlaylist = false
                }
            } else {
                showPlaylist = false
            }
            
            var privateEvent : Bool? = false
            
            if let eventType =  (eventDetailsResponse?.eventInfo?.type) , eventType.caseInsensitiveCompare("private") == ComparisonResult.orderedSame {
                if let IsCollaborationEnabled = eventDetailsResponse?.eventInfo?.IsCollaborationEnabled, IsCollaborationEnabled == false {
                    privateEvent = true
                } else {
                    privateEvent = false
                }
            } else {
                privateEvent = false
            }
            
            detailObj.privateEvent = privateEvent
            detailObj.showPlaylist = showPlaylist
            pushStoryObj(obj: detailObj, on: self)
        }
        else {
            //GLOBAL().showAlert(APPLICATION.applicationName, message: "Login to join the conversation!", actions: nil)
            FacebookLoginManager.sharedInstance.startLoginProcess(viewController: self, isFromEventDetails: true)
        }
    }

	@IBAction func playListButtonEvent(_ sender: Any) {
        if UserInfo.sharedInstance.getUserDefault(key: UNUserInfoKeys.accessToken) != nil {
            let detailObj = makeStoryObj(storyboard: PlaylistStoryboard, Identifier: "IDEventPlayListsVC") as! EventPlayListsViewController
            detailObj.eventId = eventId
            
            var showPlaylist : Bool? = false
            if let eventStatus =  (eventDetailsResponse?.eventInfo?.eventStatus) {
                
                
                if eventStatus.isUserAdmin || eventStatus.isUserArtist {
                    showPlaylist = true
                } else {
                    showPlaylist = false
                }
            } else {
                showPlaylist = false
            }
            
            var privateEvent : Bool? = false
            
            if let eventType =  (eventDetailsResponse?.eventInfo?.type) , eventType.caseInsensitiveCompare("private") == ComparisonResult.orderedSame {
                if let IsCollaborationEnabled = eventDetailsResponse?.eventInfo?.IsCollaborationEnabled, IsCollaborationEnabled == false {
                    privateEvent = true
                } else {
                    privateEvent = false
                }
            } else {
                privateEvent = false
            }
            
            detailObj.privateEvent = privateEvent
            detailObj.showPlaylist = showPlaylist
            pushStoryObj(obj: detailObj, on: self)
        }
        else {
            //GLOBAL().showAlert(APPLICATION.applicationName, message: "Login to join the conversation!", actions: nil)
            FacebookLoginManager.sharedInstance.startLoginProcess(viewController: self, isFromEventDetails: true)
        }
    }
    
    @IBAction func aboutUsButtonEvent(_ sender: Any) {
        let detailObj = makeStoryObj(storyboard: EventModuleStoryboard, Identifier: "IDEventAboutVC") as! AboutDetailViewController
        detailObj.detailTxt = self.eventDetailsResponse?.eventInfo?.eventDescription
        detailObj.LocationTxt = (self.eventDetailsResponse?.eventInfo?.eventLocation?.locationName)
        pushStoryObj(obj: detailObj, on: self)
    }
    
    @IBAction func artistButtonEvent(_ sender: Any) {
        if UserInfo.sharedInstance.getUserDefault(key: UNUserInfoKeys.accessToken) != nil {
            let artistListVC = makeStoryObj(storyboard: EventModuleStoryboard, Identifier: "IDArtistListVC") as! ArtistListViewController
            artistListVC.eventId = eventId
            pushStoryObj(obj: artistListVC, on: self)
        } else {
            //GLOBAL().showAlert(APPLICATION.applicationName, message: "Login to view artists!", actions: nil)
            FacebookLoginManager.sharedInstance.startLoginProcess(viewController: self, isFromEventDetails: true)
        }
        
    }
    
    func timediffernce() -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ" //Your date format //yyyy-MM-dd'T'HH:mm:ss-mm:ss
        
        //dateFormatter.timeZone = TimeZone(secondsFromGMT: 0)
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.timeZone = NSTimeZone(name: "PT") as TimeZone!
        if self.eventDetailsResponse?.eventInfo?.islivedatetime != nil {
            let date = dateFormatter.date(from: (self.eventDetailsResponse?.eventInfo?.islivedatetime)!) //according to date format your date string
            let now = Date()
            let timeOffset = now.offset(from:date! ) //
            return ("Went live \(timeOffset) ago")
        } else {
            return ("Went live few mins ago")
        }
    }
    
    // 3. this method is called when a tap is recognized
    func handleTap(sender: UITapGestureRecognizer) {
        let detailObj = makeStoryObj(storyboard: storyboard_R1, Identifier: "IDProfileVC") as! ProfileViewController
        detailObj.isFanProfile = true
        let userID = (UserInfo.sharedInstance.getUserDefault(key: UNUserInfoKeys.userID) as? String)!

        detailObj.userID = userID
        //detailObj.userID = String.init(format: "%ld", (fansaccobj?.id)!)
        pushStoryObj(obj: detailObj, on: self)
    }
    
    func handleImageTap(sender: UITapGestureRecognizer) {
        let detailObj = makeStoryObj(storyboard: EventModuleStoryboard, Identifier: "IDImageVC") as! ImageViewController
        detailObj.imageURL = eventImageURL!
        self.navigationController?.present(detailObj, animated: true, completion: nil)
    }
    
    func attributedLabel(_ label: TTTAttributedLabel!, didSelectLinkWith url: URL!) {
        if let urlToString = url.absoluteString.removingPercentEncoding {
            if urlToString.length > 0 {
                self.openEventDetailsOnFacebookNew(strName: urlToString)
            }
        }
    }
    
    func changeEventFirstButton(buttonTitle: String, buttonImage: String, buttonAction: EventStates) {
        interestedButton.setTitle(buttonTitle, for: UIControlState.normal)
        firstActionImageView.image = UIImage.init(named: buttonImage)
        interestedButton.tag = buttonAction.rawValue
        
        let firstActionGesture = UITapGestureRecognizer(target: self, action: #selector(firstActionEvent(sender:)))
        firstActionView.isUserInteractionEnabled = true
        firstActionView.tag = buttonAction.rawValue
        firstActionView.addGestureRecognizer(firstActionGesture)
    }
    
    func changeEventSecondButton(buttonTitle: String, buttonImage: String, buttonAction: EventStates) {
        secondActionButton.setTitle(buttonTitle, for: UIControlState.normal)
        secondActionImageView.image = UIImage.init(named: buttonImage)
        secondActionButton.tag = buttonAction.rawValue
        
        let secondActionGesture = UITapGestureRecognizer(target: self, action: #selector(secondActionEvent(sender:)))
        secondActionView.isUserInteractionEnabled = true
        secondActionView.tag = buttonAction.rawValue
        secondActionView.addGestureRecognizer(secondActionGesture)
    }
    
    func handleArtistClickEvent(sender: UITapGestureRecognizer) {
        artistButtonEvent(sender)
    }
    
    func handleAboutClickEvent(sender: UITapGestureRecognizer) {
        aboutUsButtonEvent(sender)
    }
    
    func firstActionEvent(sender: UITapGestureRecognizer) {
        let view = sender.view
        
        if let eventStateValue = view?.tag {
            firstActionEventAPI(eventStateValue: eventStateValue)
        }
        
    }
    
    func secondActionEvent(sender: UITapGestureRecognizer) {
        let view = sender.view
        
        if let eventStateValue = view?.tag {
            secondActionEventAPI(eventStateValue: eventStateValue)
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
