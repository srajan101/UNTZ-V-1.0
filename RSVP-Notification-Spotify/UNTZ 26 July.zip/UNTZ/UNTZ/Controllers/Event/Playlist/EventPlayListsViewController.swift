//
//  EventPlayListsViewController.swift
//  UNTZ
//
//  Created by Gaurang Pandya on 13/03/18.
//  Copyright © 2018 Mahesh Sonaiya. All rights reserved.
//

import UIKit

class EventPlayListsViewController: UIViewController , UITableViewDelegate,UITableViewDataSource {
    
    open var eventId : Int?
    open var showPlaylist : Bool? = false
    open var privateEvent : Bool? = false
    
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var titleTextfield: UITextField!
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var headerLabel: UILabel!
    
    @IBOutlet weak var headerViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var noresultimgView: UIImageView!
    @IBOutlet weak var noresultLbl: UILabel!
    @IBOutlet weak var privateEventMessageLabel: UILabel!
    var eventPlayListArray = NSMutableArray()


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(self.reloadnotificationbar),
            name: NSNotification.Name(rawValue: "ReloadBellIcon"),
            object: nil)
        managePrivateEvent()
        
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(sender:)))
        headerLabel.isUserInteractionEnabled = true
        headerLabel.addGestureRecognizer(tapGesture)
        
        //eventPlayListCell
        tblView.register(UINib(nibName: "EventPlayListCell", bundle: nil), forCellReuseIdentifier: "eventPlayListCell")
        tblView.estimatedRowHeight = tblView.rowHeight
        tblView.rowHeight = UITableViewAutomaticDimension
        
        
        headerView.layer.borderColor = UIColor.lightGray.cgColor
        headerView.layer.borderWidth = 1.0
        headerView.layer.cornerRadius = 3.5

        if showPlaylist! && (privateEvent == false){
            headerView.isHidden = false
            headerViewHeightConstraint.constant = 40
        } else {
            headerView.isHidden = true
            headerViewHeightConstraint.constant = 0
        }
    }
    deinit {
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "ReloadBellIcon"), object: nil)
    }
    
    @objc func reloadnotificationbar(notification: NSNotification){
        //do stuff
        reloadNavBar(self)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated);
        
        addCustomNavBar(self, isMenuRequired: false, rightButtonTitle: nil, rightButtonImage: "", title: "Event Playlists", backhandler: {
            self.navigationController?.popViewController(animated: true)
        }){
            self.moveToNotification()
        }
        
    }
    
    func displaySuggestedText(isUserHostOrArtist : Bool) {
        if (isUserHostOrArtist) {
            let main_string = "To add songs to the Event Playlists, see the Suggested Songs."
            let string_to_color = "Suggested Songs"
            
            let range = (main_string as NSString).range(of: string_to_color)
            
            let attributedString = NSMutableAttributedString(string:main_string)
            
            let attributes: [String:AnyObject] =
                [NSForegroundColorAttributeName : UIColor.init(red: 190/255, green: 20/255, blue: 17/255, alpha: 1.0),
                 NSUnderlineStyleAttributeName : NSUnderlineStyle.styleSingle.rawValue as AnyObject]
            
            attributedString.addAttributes(attributes, range: range)
            headerLabel.attributedText = attributedString
        } else {
            let main_string = "See Suggested Songs and vote for your favorite songs."
            let string_to_color = "Suggested Songs"
            
            let range = (main_string as NSString).range(of: string_to_color)
            
            let attributedString = NSMutableAttributedString(string:main_string)
            
            let attributes: [String:AnyObject] =
                [NSForegroundColorAttributeName : UIColor.init(red: 190/255, green: 20/255, blue: 17/255, alpha: 1.0),
                 NSUnderlineStyleAttributeName : NSUnderlineStyle.styleSingle.rawValue as AnyObject]
            
            attributedString.addAttributes(attributes, range: range)
            headerLabel.attributedText = attributedString
        }
        
        
    }
    
    func moveToNotification() {
        let detailObj = makeStoryObj(storyboard: storyboard_R1, Identifier: "IDNotificationVC") as! NotificationsViewController
        detailObj.isPushVC = true
        pushStoryObj(obj: detailObj, on: self)
    }
    
    func managePrivateEvent() {
        if privateEvent == true {
            headerView.isHidden = true
            headerLabel.isHidden = true
            tblView.isHidden = true
            privateEventMessageLabel.isHidden = false
        } else {
            headerView.isHidden = false
            headerLabel.isHidden = false
            tblView.isHidden = false
            privateEventMessageLabel.isHidden = true
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if privateEvent! == false {
            if eventPlayListArray.count > 0
            {
                eventPlayListArray.removeAllObjects()
            }
            self.getListOfEventPlaylist()
        }
    }
    
    func handleTap(sender: UITapGestureRecognizer) {
        let detailObj = makeStoryObj(storyboard: PlaylistStoryboard, Identifier: "IDSuggestedPlayListsVC") as! SuggestedPlaylistViewController
        
        detailObj.eventId = eventId
        detailObj.showPlaylist = showPlaylist
        pushStoryObj(obj: detailObj, on: self)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.eventPlayListArray.count;
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 80 //Choose your custom row height
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:EventPlayListCell = tableView.dequeueReusableCell(withIdentifier: "eventPlayListCell") as! EventPlayListCell
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        let infoObj = eventPlayListArray.object(at: (indexPath as NSIndexPath).row) as? UNEventPlaylistInfo
         cell.eventNameLable.text = infoObj?.playlistName
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let infoObj = eventPlayListArray.object(at: (indexPath as NSIndexPath).row) as? UNEventPlaylistInfo
        let detailObj = makeStoryObj(storyboard: PlaylistStoryboard, Identifier: "IDPlayListVC") as! PlayListViewController
        detailObj.eventId = eventId
        detailObj.eventInfoObj = infoObj
        detailObj.showPlaylist = showPlaylist
        pushStoryObj(obj: detailObj, on: self)
    }
    @IBAction func clickCreateEvent(_ sender: Any) {
        if titleTextfield.text?.count == 0 {
            GLOBAL().showAlert(APPLICATION.applicationName, message: "Please enter playlist name!", actions: nil)

            return
        } else {
            titleTextfield.endEditing(true)
            
            createPlaylist(playListName: (titleTextfield.text)!)
        }
    }
    
    func createPlaylist(playListName : String) {
        GLOBAL().showLoadingIndicatorWithMessage("")
        UNTZReqeustManager.sharedInstance.apiCreateEventPlaylist(eventId!, playlistName: playListName) {
            (feedResponse) -> Void in
            GLOBAL().hideLoadingIndicator()
            
            if let downloadError = feedResponse.error{
                print(downloadError)
                GLOBAL().showAlert(APPLICATION.applicationName, message: downloadError.localizedDescription, actions: nil)
            } else {
                GLOBAL().hideLoadingIndicator()
                
                if let dictionary = feedResponse.responseDict as? Dictionary<String, AnyObject>{
                    let dataValue = dictionary["data"] as! Bool!
                    
                    if dataValue == true {
                        self.titleTextfield.text = nil
                        self.refreshEventPlaylist()
                    } else {
                        GLOBAL().showAlert(APPLICATION.applicationName, message: "There was an error processing your request!", actions: nil)
                    }
                    
                }
            }
        }
    }

    func refreshEventPlaylist() {
        if eventPlayListArray.count > 0 {
            eventPlayListArray.removeAllObjects()
        }
        getListOfEventPlaylist()
    }
    
    func getListOfEventPlaylist() {
        GLOBAL().showLoadingIndicatorWithMessage("")
        UNTZReqeustManager.sharedInstance.apiGetEventPlaylist(eventId!, excludeTracks: true) {
            (feedResponse) -> Void in
            GLOBAL().hideLoadingIndicator()
            
            if let downloadError = feedResponse.error{
                print(downloadError)
                GLOBAL().showAlert(APPLICATION.applicationName, message: downloadError.localizedDescription, actions: nil)
            } else {
                GLOBAL().hideLoadingIndicator()
                
                if let dictionary = feedResponse.responseDict as? Dictionary<String, AnyObject>{
                    
                    let data = dictionary["data"] as! Dictionary<String, AnyObject>
                    
                    if let userEventStatus = data["userEventStatus"] as? Dictionary<String, AnyObject> {
                        var isUserAdminValue : Bool = false
                        var isUserArtistValue : Bool = false
                        
                        if let isUserAdmin = userEventStatus["isUserAdmin"] as? Bool {
                            if isUserAdmin == true {
                                isUserAdminValue = true
                            } else {
                                isUserAdminValue = false
                            }
                        }
                        
                        if let isUserArtist = userEventStatus["isUserArtist"] as? Bool {
                            if isUserArtist == true {
                                isUserArtistValue = true
                            } else {
                                isUserArtistValue = false
                            }
                        }
                        
                        if isUserAdminValue || isUserArtistValue {
                            self.showPlaylist = true
                        } else {
                            self.showPlaylist = false
                        }
                    } else {
                        self.showPlaylist = false
                    }
                    
                    if self.showPlaylist! {
                        self.headerView.isHidden = false
                        self.headerViewHeightConstraint.constant = 40
                    } else {
                        self.headerView.isHidden = true
                        self.headerViewHeightConstraint.constant = 0
                    }
                    
                    self.displaySuggestedText(isUserHostOrArtist: self.showPlaylist!)
                    
                    self.headerLabel.isHidden = false
                    if let playlistdata = data["eventPlaylists"] as? Array<Dictionary<String, AnyObject>> {
                        for playlistDict in playlistdata{
                            let playlistInfo = UNEventPlaylistInfo.init(jsonDict: playlistDict)
                            self.eventPlayListArray.add(playlistInfo)
                        }
                        if (self.eventPlayListArray.count == 0){
                            self.tblView.isHidden = true
                            self.noresultimgView.isHidden = false
                            self.noresultLbl.isHidden = false
                        }else{
                            self.tblView.isHidden = false
                            self.noresultimgView.isHidden = true
                            self.noresultLbl.isHidden = true
                            
                            self.tblView.reloadData()
                        }
                    }
                }
            }
        }
    }
    
    
}
