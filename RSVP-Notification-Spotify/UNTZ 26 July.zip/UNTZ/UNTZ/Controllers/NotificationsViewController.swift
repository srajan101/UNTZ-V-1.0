//
//  NotificationsViewController.swift
//  UNTZ
//
//  Created by Mahesh Sonaiya on 14/04/18.
//  Copyright © 2018 Mahesh Sonaiya. All rights reserved.
//

import UIKit

class NotificationsViewController: UIViewController , UITableViewDelegate, UITableViewDataSource{
    
    @IBOutlet weak var notificationTableView: UITableView!
    @IBOutlet weak var noresultLabel: UNLabel!
    open var isPushVC : Bool?
    open var accountId : String?
    var offset : Int = 0
    var bolDecelerate : Bool = false
    var isMoreEventAvailable : Bool = false
    var pageIndex : Int = 1
    
    var notificationRespone : PushNotificationInfo?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        notificationTableView.register(UINib(nibName: "NotificationCell", bundle: nil), forCellReuseIdentifier: "notificationcell")
        notificationTableView.estimatedRowHeight = notificationTableView.rowHeight
        notificationTableView.rowHeight = UITableViewAutomaticDimension
        
        //self.getListOfFans(self.userId!)
        
        
        if NotificationState.initialLoadFlag {
            NotificationState.initialLoadFlag = false
          NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ReloadMenu"), object: self)
        }
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        var isMenuRequired = true
        if(isPushVC)!{
            isMenuRequired = false
        }
        addCustomNavBar(self, isMenuRequired: isMenuRequired, rightButtonTitle: nil, rightButtonImage: nil, title: "Notifications", backhandler: {
            //self.navigationController?.popViewController(animated: true)
            if(self.isPushVC)! {
                self.navigationController?.popViewController(animated: true)
            } else {
                self.showLeftView()
            }
        }){

        }
    }
    
    
    func showLeftView() {
        if(isPushVC)!{
            self.navigationController?.popViewController(animated: true)
        }
        else{
            sideMenuController?.showLeftView(animated: true, completionHandler: nil)
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.getListOfNotifications()
        //self.notificationTableView.reloadData()
    }
    
    @IBAction func backClicked(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK :- Get List Of Notifications
    
    func getListOfNotifications() {
        self.noresultLabel.isHidden = true
        
        if self.notificationRespone == nil || self.notificationRespone?.notificationList?.count==0{
            GLOBAL().showLoadingIndicatorWithMessage("")
        }
        
        UNTZReqeustManager.sharedInstance.apiGetNotificationList(offset) {
        (feedResponse) -> Void in
            GLOBAL().hideLoadingIndicator()
            
            if let downloadError = feedResponse.error{
                print(downloadError)
                GLOBAL().showAlert(APPLICATION.applicationName, message: downloadError.localizedDescription, actions: nil)
            } else {
                GLOBAL().hideLoadingIndicator()
                
                if let dictionary = feedResponse.responseDict as? Dictionary<String, AnyObject>{
                    if(self.offset == 0) {
                        self.notificationRespone = PushNotificationInfo.init(jsonDict:dictionary["data"] as! Dictionary<String, AnyObject>)
                        if self.notificationRespone?.notificationList?.count == 0 {
                            self.noresultLabel.isHidden = false
                        }else{
                            self.noresultLabel.isHidden = true
                        }
                        
                    } else {
                        self.notificationRespone?.appendData(jsonDict:dictionary["data"] as! Dictionary<String, AnyObject>)
                    }
                    
                    if(((self.notificationRespone?.numberOfItemsPerPage)! * self.pageIndex) == (self.notificationRespone?.notificationList?.count)) {
                        self.isMoreEventAvailable = true
                    } else {
                        self.isMoreEventAvailable = false
                        self.notificationTableView.tableFooterView?.isHidden = true
                    }
                    self.notificationTableView.reloadData()
                }
            }
        }
    }
    // number of rows in table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.notificationRespone == nil {
            return 0
        } else
        {
            return (self.notificationRespone!.notificationList!.count);
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        var width_val : CGFloat
        var height_val : CGFloat
        
        let xVal = 20;
        width_val = tableView.frame.size.width - (67)
        height_val = 0
        
         let objDetails = self.notificationRespone?.notificationList?[indexPath.row]
        let modelobj  = objDetails?.notificationFormatModel

        let heightdeslbl = self.height(string: self.getMutablestringSentence(mainStr:(objDetails?.notificationTextFormat)!,notiObj: modelobj!)! , withConstrainedWidth: width_val - (2*CGFloat(xVal)), font: UIFont(name: "Roboto-Regular", size: 15)!)
        height_val += heightdeslbl + 20 + 20;
        return height_val;//Choose your custom row height
    }
    
    // create a cell for each table view row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        let cell:NotificationCell = tableView.dequeueReusableCell(withIdentifier: "notificationcell") as! NotificationCell
        //cell.selectionStyle = UITableViewCellSelectionStyle.none
        let objDetails = self.notificationRespone?.notificationList?[indexPath.row]
        let modelobj  = objDetails?.notificationFormatModel
        cell.datailLabel.attributedText = self.getMutablestringSentence(mainStr:(objDetails?.notificationTextFormat)!,notiObj: modelobj!)
        if modelobj?.actorPictureUrl != nil{
            cell.profileImageView.sd_setImage(with: URL.init(string: (modelobj?.actorPictureUrl)!), completed: { (image, error, cacheType, imageURL) in
                if image != nil {
                    //cell.linkImageview.stopAnimationOfImage()
                }else{
                    let Image: UIImage = UIImage(named: "default_user_pict")!
                    cell.profileImageView.image = Image
                }
            })
        }else{
            let Image: UIImage = UIImage(named: "default_user_pict")!
            cell.profileImageView.image = Image
        }
        cell.timeLabel.text = self.timediffernce(datestr: (objDetails?.createdDateTime)!)
        
        return cell
    }
 
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if (self.isMoreEventAvailable) {
            let lastSectionIndex = tableView.numberOfSections - 1
            let lastRowIndex = tableView.numberOfRows(inSection: lastSectionIndex) - 1
            if indexPath.section ==  lastSectionIndex && indexPath.row == lastRowIndex {
                //  print("this is the last cell")
                
                let imageData = NSData(contentsOf: Bundle.main.url(forResource: "animationImg",withExtension: "gif")!)
                let  hudImgView = UIImageView(image: UIImage.sd_animatedGIF(with: imageData as Data!))
                let myNewView = UIView(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: tableView.bounds.width, height: CGFloat(100)))
                hudImgView.frame = CGRect(x: CGFloat((myNewView.frame.width-100)/2), y: CGFloat(0), width: CGFloat(100), height: CGFloat(100))
                myNewView.addSubview(hudImgView)
                tableView.tableFooterView = myNewView
                self.notificationTableView.tableFooterView?.isHidden = false
            }
        } else {
            tableView.tableFooterView = nil
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let objDetails = self.notificationRespone?.notificationList?[indexPath.row]
        let modelobj  = objDetails?.notificationFormatModel
        
        
        switch (objDetails?.notificationType)! {
        case "event_artist_added":
            print("move event detail")
            self.movetoEventDetail(NotiObj: modelobj!)
        
        case "event_invitation_received":
            print("move event detail")
            self.movetoEventDetail(NotiObj: modelobj!)
            
        case "event_invitation_accepted":
            print("move event detail")
            self.movetoEventDetail(NotiObj: modelobj!)
            
        case "event_starting_reminder":
            print("move event detail")
            self.movetoEventDetail(NotiObj: modelobj!)
            
        case "event_artist_removed":
            print("move event detail")
            self.movetoEventDetail(NotiObj: modelobj!)

        case "event_song_requested":
            print("move event_requests")
            self.movetoEventRequest(NotiObj: modelobj!)
            
        case "event_requested_song_accepted":
            print("move event_requests")
            self.movetoEventRequest(NotiObj: modelobj!)
            
        case "event_suggested_playlist_added":
            print("move event_suggested_playlists")
            self.movetoSuggestedPlayLists(NotiObj: modelobj!)
            
        case "event_suggested_playlist_removed":
            print("move event_suggested_playlists")
             self.movetoSuggestedPlayLists(NotiObj: modelobj!)
            
        case "event_vote_for_suggested_playlist_track":
            print("move event_suggested_playlists tracks")
             self.movetoSuggestedPlayListsTracks(NotiObj: modelobj!)
            
        case "event_delete_event_playlist":
            print("move event_playlists")
            self.movetoEventPlayList(NotiObj: modelobj!)
            
        case "event_rename_event_playlist":
            print("move event_playlists")
            self.movetoEventPlayList(NotiObj: modelobj!)
            
        case "event_create_event_playlist":
            print("move event_playlists")
            self.movetoEventPlayList(NotiObj: modelobj!)
            
        case "event_suggested_track_addedto_eventplaylist":
            print("move event_playlists")
            self.movetoEventPlayListTracks(NotiObj: modelobj!)
            
        case "event_delete_event_playlist_track":
            print("move event_playlists")
            self.movetoEventPlayListTracks(NotiObj: modelobj!)
            
        case "event_vote_for_event_playlist_track":
            print("move event_playlists")
            self.movetoEventPlayListTracks(NotiObj: modelobj!)
            
        case "profile_follow", "profile_follows_during_signup":
            print("move profile detail")
            self.movetoProfileDetail(NotiObj: modelobj!)
        
        default:
            print("other")
        }
        tableView.deselectRow(at: indexPath, animated: true)
    }
    func movetoEventDetail(NotiObj :  NotificationFormatTokenModel){
        let detailObj = makeStoryObj(storyboard: EventModuleStoryboard, Identifier: "IDEventDetailsVC") as! EventDetailsViewController
        detailObj.eventId = NotiObj.entityId
        //detailObj.eventImageURL = NotiObj.actorPictureUrl
        pushStoryObj(obj: detailObj, on: self)
    }
    func movetoEventRequest(NotiObj :  NotificationFormatTokenModel){
        let detailObj = makeStoryObj(storyboard: PlaylistStoryboard, Identifier: "IDUNTrackRequestsVC") as! UNTrackRequestsVC
        detailObj.eventId = NotiObj.entityId
        detailObj.showPlaylist = false
        pushStoryObj(obj: detailObj, on: self)
    }
    func movetoSuggestedPlayLists(NotiObj :  NotificationFormatTokenModel) {
        let detailObj = makeStoryObj(storyboard: PlaylistStoryboard, Identifier: "IDSuggestedPlayListsVC") as! SuggestedPlaylistViewController
        
        detailObj.eventId = NotiObj.entityId
        detailObj.showPlaylist = false
        pushStoryObj(obj: detailObj, on: self)
    }
    
    func movetoSuggestedPlayListsTracks(NotiObj :  NotificationFormatTokenModel) {
        /*
        let detailObj = makeStoryObj(storyboard: storyboard_R1, Identifier: "IDSuggestedPlayListsVC") as! SuggestedPlaylistViewController
        
        detailObj.eventId = NotiObj.entityId
        detailObj.showPlaylist = true
        pushStoryObj(obj: detailObj, on: self)
 */
        
        let detailObj = makeStoryObj(storyboard: PlaylistStoryboard, Identifier: "IDSuggestedTracksVC") as! SuggestedPlaylistTracksViewController
        detailObj.eventId = NotiObj.entityId
        detailObj.playListId = NotiObj.subEntityId1
        detailObj.playListName = NotiObj.playlistName
        detailObj.showPlaylist = false
        detailObj.fromNotification = true
        pushStoryObj(obj: detailObj, on: self)
    }
 
    
    func movetoEventPlayList(NotiObj :  NotificationFormatTokenModel) {
        let detailObj = makeStoryObj(storyboard: PlaylistStoryboard, Identifier: "IDEventPlayListsVC") as! EventPlayListsViewController
        detailObj.eventId = NotiObj.entityId
        
        detailObj.showPlaylist = false
        pushStoryObj(obj: detailObj, on: self)
    }
    
    func movetoEventPlayListTracks(NotiObj :  NotificationFormatTokenModel) {
        let detailObj = makeStoryObj(storyboard: PlaylistStoryboard, Identifier: "IDPlayListVC") as! PlayListViewController
        detailObj.eventId = NotiObj.entityId
        detailObj.playListId = NotiObj.subEntityId1
        detailObj.playListName = NotiObj.playlistName
        detailObj.showPlaylist = false
        detailObj.fromNotification = true
        pushStoryObj(obj: detailObj, on: self)
    }
    
    func movetoProfileDetail(NotiObj :  NotificationFormatTokenModel) {
        let detailObj = makeStoryObj(storyboard: storyboard_R1, Identifier: "IDProfileVC") as! ProfileViewController
        
        if let userId = NotiObj.entityId {
            let accountId = Int(UserInfo.sharedInstance.getUserDefault(key: UNUserInfoKeys.accountID) as! Int)
            
            if userId == accountId {
                detailObj.isFanProfile = false
            } else {
                detailObj.isFanProfile = true
            }
        } else {
            detailObj.isFanProfile = false
        }
        detailObj.userID = String.init(format: "%ld",  NotiObj.entityId!)
        pushStoryObj(obj: detailObj, on: self)
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        if (bolDecelerate) {
            scrollViewReload(scrollView)
        }
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        bolDecelerate = decelerate;
        
        if (!bolDecelerate) {
            scrollViewReload(scrollView)
        }
    }
    
    private func scrollViewReload(_ scrollView : UIScrollView) {
        let endScrolling = scrollView.contentOffset.y + scrollView.frame.size.height;
        
        if (endScrolling >= scrollView.contentSize.height - 100){
            if (self.isMoreEventAvailable) {
                pageIndex = pageIndex + 1
                offset = (notificationRespone?.nextIndex)!
                self.isMoreEventAvailable = false;
                self.getListOfNotifications()
            }
        }
    }
    
    func getMutablestringSentence(mainStr : String , notiObj :NotificationFormatTokenModel ) -> NSAttributedString? {
       // let boldattr = [NSFontAttributeName: UIFont(name: "Roboto-Medium", size: 12)!]
        let boldattr : [String : Any] = [NSFontAttributeName : UIFont(name: "Roboto-Medium", size: 15.0)!, NSForegroundColorAttributeName : UIColor.black]
        let normalattr : [String : Any] = [NSFontAttributeName : UIFont(name: "Roboto-Regular", size: 14.0)!, NSForegroundColorAttributeName : UIColor.black]

        let newStr = NSMutableAttributedString()
        let myStringArr = mainStr.components(separatedBy: " ")

        var i : Int = 0
        let count = myStringArr.count
        
        for objects in myStringArr {
            i = i + 1
            var attributedString = NSMutableAttributedString()
            if objects.range(of:"__") != nil {
                let valuestr = self.getValuefromKeystr(keyStr: objects, Obj: notiObj)
                attributedString =  NSMutableAttributedString(string:valuestr!, attributes:boldattr)
            }
            else{
                attributedString = NSMutableAttributedString(string:objects, attributes:normalattr)
            }
           let spaceattributedString = NSMutableAttributedString(string: " ")
            newStr.append(attributedString)
            if i == count {
                // do not add space
            } else {
                newStr.append(spaceattributedString)
            }
        }
        
        let dotString = String.init(".")
        let dotattributedString =  NSMutableAttributedString(string:dotString!, attributes:normalattr)
        newStr.append(dotattributedString)
        return newStr
    }
    func getValuefromKeystr(keyStr : String ,Obj :NotificationFormatTokenModel) -> String? {
        let key1 = keyStr.replace(target: "__", withString:"")
        let key = key1.replace(target: ".", withString:"")
        var value = ""
        
        switch key {
        case "actorName":
            value = Obj.actorName!;
        case "requestorName":
            value = Obj.requestorName!;
        case "artistName":
            value = Obj.artistName!;
        case "songName":
            value = Obj.songName!;
        case "songArtistName":
            value = Obj.songArtistName!;
        case "playlistName":
            value = Obj.playlistName!;
        case "eventName":
            value = Obj.eventName!;
        case "eventStartDate":
            value = Obj.eventStartDate!;
        case "oldPlaylistName":
            value = Obj.oldPlaylistName!;
        case "newPlaylistName":
            value = Obj.newPlaylistName!;
        case "entityViewName":
            value = Obj.entityViewName!;
        case "eventLocation":
            value = Obj.eventLocation!;
        case "eventStartDateTime":
            value = Obj.eventStartDateTime!;
        default:
            value = ""
        }
        
        
        return value
    }
    func height(string: NSAttributedString,withConstrainedWidth width: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: width, height: .greatestFiniteMagnitude)
        let boundingBox = string.boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, context: nil)
        
        return boundingBox.height
    }
    func timediffernce(datestr : String) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ" //Your date format //yyyy-MM-dd'T'HH:mm:ss-mm:ss
        //"2018-04-30T10:24:38.7631605+00:00"
        //dateFormatter.timeZone = TimeZone(secondsFromGMT: 0)
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.timeZone = NSTimeZone(name: "PT") as TimeZone!
        if datestr != nil {
            let date = dateFormatter.date(from: datestr) //according to date format your date string
            let now = Date()
            let timeOffset = now.offset(from:date! ) //
            return ("\(timeOffset) ago")
        } else {
            return ("few mins ago")
        }
    }
}
