//
//  AzureCloudConfig.swift
//  UNTZ
//
//  Created by Mahesh Sonaiya on 13/07/18.
//  Copyright © 2018 Mahesh Sonaiya. All rights reserved.
//

import Foundation
class AzureCloudConfig : NSObject {
    static let UNTZAzureCloudContainerURL = "https://untz.blob.core.windows.net/"
    static let usingSAS = false
    
    // If using Shared Key access, fill in your credentials here and un-comment the "UsingSAS" line:
    static let UNTZAzureCloudconnectionString = "DefaultEndpointsProtocol=https;AccountName=untz;AccountKey=lV0Ntg3tsZwAtSQWt8WglJwlbvWEtZstZxwj3eK65zKjmxCdSTH0bNvcZZzNuRRfwLCzDAuYNp6WN0yhgVXF3Q==;EndpointSuffix=core.windows.net"
    static let UNTZAzureCloudContainerName = "untz-uploads"
}
