//
//  AzureCloudStorageManager.swift
//  UNTZ
//
//  Created by Mahesh Sonaiya on 13/07/18.
//  Copyright © 2018 Mahesh Sonaiya. All rights reserved.
//

import Foundation
import AZSClient

class AzureCloudStorageManager : NSObject {
    //sharedInstance
    static let sharedInstance = AzureCloudStorageManager()
    fileprivate var AZSCloudBlobContainerObj : AZSCloudBlobContainer?
    
    func initAzureCloudStorageManager() {
        let storageAccount : AZSCloudStorageAccount
        try! storageAccount = AZSCloudStorageAccount(fromConnectionString: AzureCloudConfig.UNTZAzureCloudconnectionString)
        let blobClient = storageAccount.getBlobClient()
        self.AZSCloudBlobContainerObj = blobClient.containerReference(fromName: AzureCloudConfig.UNTZAzureCloudContainerName)
        
        if self.AZSCloudBlobContainerObj != nil {
            print("Container Created : \(AZSCloudBlobContainerObj?.name ?? "Container")")
        }
    }
    
    open func getAZSCloudBlobContainer() -> AZSCloudBlobContainer? {
        return AZSCloudBlobContainerObj
    }
}
