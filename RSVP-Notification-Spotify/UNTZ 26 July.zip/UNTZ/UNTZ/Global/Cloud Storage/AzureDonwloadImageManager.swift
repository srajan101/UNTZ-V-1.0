//
//  AzureDonwloadImageManager.swift
//  UNTZ
//
//  Created by Mahesh Sonaiya on 13/07/18.
//  Copyright © 2018 Mahesh Sonaiya. All rights reserved.
//

import Foundation
import AZSClient
import SDWebImage

typealias downloadImageCompletionHandler = (DownloadCloudImageResponse) -> Void

struct DownloadCloudImageResponse {
    var error: Error?
    var image : UIImage?
    
    init(image: UIImage?, error: Error?){
        self.image = image
        self.error = error
    }
}

class AzureDonwloadImageManager : NSObject {
    //sharedInstance
    static let sharedInstance = AzureDonwloadImageManager()

    open func downloadBlobFromURL(blobName : String?) -> AZSCloudBlob? {
        if let blobName = blobName {
            let AZSCloudBlobObj = AzureCloudStorageManager.sharedInstance.getAZSCloudBlobContainer()?.blockBlobReference(fromName: blobName)
            return AZSCloudBlobObj
        } else {
            return nil
        }
    }
    
    func downloadCloudImage(at blobName: String, completionHandler:@escaping downloadImageCompletionHandler) {
        let imageCache = SDImageCache.shared()
        imageCache.queryCacheOperation(forKey: blobName, done: { (image, data, cacheType) in
            // Return successful result
            if image != nil {
                let imageResponse = DownloadCloudImageResponse.init(image: image, error: nil)
                completionHandler(imageResponse)
            } else {
                let blob = AzureDonwloadImageManager.sharedInstance.downloadBlobFromURL(blobName: blobName)
                
                blob?.downloadToData(completionHandler: { (error, data) in
                    if error == nil {
                        if let data = data {
                            DispatchQueue.main.async {
                                let image = UIImage.init(data: data)
                                imageCache.store(image, forKey: blobName, completion: {
                                })
                                let imageResponse = DownloadCloudImageResponse.init(image: image, error: nil)
                                completionHandler(imageResponse)
                            }
                        }
                    } else {
                        print(error?.localizedDescription ?? "")
                        let imageResponse = DownloadCloudImageResponse.init(image: nil, error: error)
                        completionHandler(imageResponse)
                    }
                })
            }
        })
    }
}
